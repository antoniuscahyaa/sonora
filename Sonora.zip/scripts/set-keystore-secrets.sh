#!/usr/bin/env bash
# Memasukkan keystore lama Anda ke GitHub Secrets, lalu (opsional) memicu build.
#
# Pakai:   ./scripts/set-keystore-secrets.sh <keystore.jks> [alias] [owner/repo]
# Contoh:  ./scripts/set-keystore-secrets.sh ~/keys/lama.jks mykey akun/sonora
#
# Jika GitHub CLI (gh) ada dan sudah login (gh auth login), semua secret diisi otomatis.
# Jika tidak, script membuat keystore.b64.txt dan menampilkan langkah mengisi manual
# di GitHub: Settings > Secrets and variables > Actions > New repository secret.
set -euo pipefail

KS="${1:-}"
ALIAS="${2:-}"
REPO="${3:-}"

if [ -z "$KS" ] || [ ! -f "$KS" ]; then
  echo "Pakai: $0 <keystore.jks> [alias] [owner/repo]" >&2
  exit 1
fi

if [ -z "$ALIAS" ]; then read -r -p "Alias key: " ALIAS; fi
read -r -s -p "Password keystore: " SP; echo
read -r -s -p "Password key (Enter = sama dengan keystore): " KP; echo
KP="${KP:-$SP}"

if command -v keytool >/dev/null 2>&1; then
  if keytool -list -keystore "$KS" -storepass "$SP" -alias "$ALIAS" >/dev/null 2>&1; then
    echo "Keystore dan alias cocok."
  else
    echo "Keystore, alias, atau password tidak cocok. Dibatalkan." >&2
    exit 1
  fi
else
  echo "(keytool tidak ditemukan, pengecekan keystore dilewati)"
fi

B64="$(base64 -w0 "$KS" 2>/dev/null || base64 "$KS" | tr -d '\n')"

if ! command -v gh >/dev/null 2>&1; then
  printf '%s' "$B64" > keystore.b64.txt
  cat <<MSG

gh tidak ditemukan. Isi 4 secret ini secara manual di repo GitHub Anda:
  KEYSTORE_BASE64   = isi file keystore.b64.txt (satu baris panjang)
  KEYSTORE_PASSWORD = password keystore
  KEY_ALIAS         = $ALIAS
  KEY_PASSWORD      = password key

Setelah itu hapus keystore.b64.txt. Jangan pernah meng-commit file itu atau keystore-nya.
MSG
  exit 0
fi

R=()
if [ -n "$REPO" ]; then R=(--repo "$REPO"); fi

printf '%s' "$B64"   | gh secret set KEYSTORE_BASE64   ${R[@]+"${R[@]}"}
printf '%s' "$SP"    | gh secret set KEYSTORE_PASSWORD ${R[@]+"${R[@]}"}
printf '%s' "$ALIAS" | gh secret set KEY_ALIAS         ${R[@]+"${R[@]}"}
printf '%s' "$KP"    | gh secret set KEY_PASSWORD      ${R[@]+"${R[@]}"}
echo "4 secret terisi."

read -r -p "Jalankan build release sekarang? [y/N] " GO
if [ "${GO:-N}" = "y" ] || [ "${GO:-N}" = "Y" ]; then
  gh workflow run build.yml ${R[@]+"${R[@]}"} -f build_type=release
  echo "Build dipicu. Lihat hasilnya di tab Actions."
fi
