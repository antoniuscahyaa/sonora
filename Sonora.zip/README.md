# Sonora

Pemutar musik Android (Kotlin, tanpa library tambahan) dengan UI bergaya DialChat.
Package: `com.sonora.app`. Fitur: daftar lagu, album, artis (artis kolaborasi digabung ke artis utama), pencarian,
favorit (ikon bintang di header), Sedang diputar, antrean, acak/ulang, timer tidur,
notifikasi media + tombol headset, dan halaman Pengaturan (tema, library, pemutaran).

## Build lewat GitHub Actions

1. Upload seluruh isi folder ini ke repo GitHub (termasuk folder `.github`).
   Jika `.github` tidak ikut terupload, buat file `.github/workflows/build.yml` lewat
   Add file > Create new file, lalu tempel isi dari zip.
2. Isi 4 secret (Settings > Secrets and variables > Actions) dengan keystore lama Anda:

   | Secret | Isi |
   |---|---|
   | `KEYSTORE_BASE64` | keystore yang di-base64 (satu baris) |
   | `KEYSTORE_PASSWORD` | password keystore |
   | `KEY_ALIAS` | alias key |
   | `KEY_PASSWORD` | password key |

   Cara cepat: `./scripts/set-keystore-secrets.sh keystore-lama.jks alias akun/sonora`
   (bisa dijalankan di Termux; butuh `gh`, kalau tidak ada script membuat `keystore.b64.txt`
   untuk ditempel manual). Script juga mengecek keystore + alias dan bisa langsung memicu build.
3. Tab Actions > Build Sonora > Run workflow. APK ada di Artifacts (`Sonora-APK`).
   Push tag `v0.1` dan APK ikut dirilis di halaman Releases.

Tanpa secret, workflow tetap jalan tapi hasilnya APK debug (bukan keystore Anda).
Jangan pernah meng-commit file keystore. `.gitignore` sudah menolak `*.jks` dan `*.keystore`.

## Struktur singkat

- `Player.kt`: pemutar tunggal (antrean, acak, ulang, audio focus, timer tidur)
- `PlaybackService.kt`: service foreground + notifikasi media + MediaSession
- `MainActivity.kt`: Lagu / Album / Artis; `NowPlayingActivity.kt`; `QueueActivity.kt`; `SettingsActivity.kt`
- `Prefs.kt`: semua preferensi; `Library.kt`: muat lagu + filter + penggabungan artis
- `res/values*/strings.xml`: Indonesia (default) dan Inggris
