package com.sonora.app

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : BaseActivity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }
    private val DANGER = Color.parseColor("#B42318")

    private lateinit var content: LinearLayout
    private lateinit var vTheme: TextView
    private lateinit var vMin: TextView
    private lateinit var vFolders: TextView
    private lateinit var vSort: TextView
    private lateinit var vSleep: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
    }

    override fun onStart() {
        super.onStart()
        updateValues()
    }

    // ---------- tampilan halaman ----------
    private fun build(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val h = LinearLayout(this)
        val r = dp(36).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BLUE)
        bg.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        h.background = bg
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(16), dp(8), dp(16), dp(16))
        h.addView(
            glassBtn(R.drawable.ic_back, getString(R.string.back)) { finish() },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        )
        val title = TextView(this)
        title.text = getString(R.string.settings)
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.setTypeface(null, Typeface.BOLD)
        h.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(h, LinearLayout.LayoutParams(MATCH, WRAP))

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, 0, 0, dp(24))
        val sv = ScrollView(this)
        sv.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        section(R.string.set_appearance)
        vTheme = valueRow(R.drawable.ic_moon, R.string.set_theme) { pickTheme() }
        switchRow(R.drawable.ic_image, R.string.set_covers, Prefs.covers(this)) { Prefs.setCovers(this, it) }

        section(R.string.set_library)
        vMin = valueRow(R.drawable.ic_timer, R.string.set_minlen) { pickMinLen() }
        vFolders = valueRow(R.drawable.ic_folder, R.string.set_folders) { pickFolders() }
        vSort = valueRow(R.drawable.ic_sort, R.string.set_sort) { pickSort() }
        switchRow(R.drawable.ic_person, R.string.set_merge, Prefs.mergeArtists(this)) { Prefs.setMergeArtists(this, it) }
        actionRow(R.drawable.ic_refresh, R.string.set_reload, false) { reloadLibrary() }

        section(R.string.set_playback)
        switchRow(R.drawable.ic_headphones, R.string.set_unplug, Prefs.pauseOnUnplug(this)) { Prefs.setPauseOnUnplug(this, it) }
        switchRow(R.drawable.ic_play, R.string.set_resume, Prefs.resumeLast(this)) { Prefs.setResumeLast(this, it) }
        switchRow(R.drawable.ic_equalizer, R.string.set_fade, Prefs.fade(this)) { Prefs.setFade(this, it) }
        vSleep = valueRow(R.drawable.ic_moon, R.string.set_sleepdef) { pickSleep() }
        switchRow(R.drawable.ic_timer, R.string.set_sleepfin, Prefs.sleepFinish(this)) { Prefs.setSleepFinish(this, it) }

        section(R.string.set_other)
        actionRow(R.drawable.ic_delete, R.string.set_clearfav, true) { confirmClearFavs() }
        actionRow(R.drawable.ic_info, R.string.set_about, false) { showAbout() }
        return root
    }

    private fun section(res: Int) {
        val tv = TextView(this)
        tv.text = getString(res)
        tv.textSize = 13f
        tv.setTextColor(LINK)
        tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(dp(20), dp(20), dp(20), dp(6))
        content.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun baseRow(ic: Int, title: Int, danger: Boolean): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(20), dp(12), dp(20), dp(12))
        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
            r.setBackgroundResource(tv.resourceId)
        }
        r.addView(icon(ic, if (danger) DANGER else MUTED), LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(16) })
        val t = TextView(this)
        t.text = getString(title)
        t.textSize = 16f
        t.setTextColor(if (danger) DANGER else INK)
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        content.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        return r
    }

    private fun valueRow(ic: Int, title: Int, onClick: () -> Unit): TextView {
        val r = baseRow(ic, title, false)
        val v = TextView(this)
        v.textSize = 13f
        v.setTextColor(MUTED)
        v.maxLines = 1
        v.ellipsize = TextUtils.TruncateAt.END
        v.maxWidth = dp(150)
        r.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
        r.setOnClickListener { onClick() }
        return v
    }

    private fun actionRow(ic: Int, title: Int, danger: Boolean, onClick: () -> Unit) {
        val r = baseRow(ic, title, danger)
        r.setOnClickListener { onClick() }
    }

    private fun switchRow(ic: Int, title: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
        val r = baseRow(ic, title, false)
        val sw = Switch(this)
        if (Build.VERSION.SDK_INT >= 23) {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
            sw.trackTintList = ColorStateList(states, intArrayOf(BLUE, LINE))
        }
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        r.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
        r.setOnClickListener { sw.toggle() }
    }

    // ---------- nilai yang ditampilkan ----------
    private fun updateValues() {
        vTheme.text = getString(
            when (Prefs.theme(this)) {
                1 -> R.string.theme_light
                2 -> R.string.theme_dark
                else -> R.string.theme_system
            }
        )
        val m = Prefs.minSec(this)
        vMin.text = if (m <= 0) getString(R.string.minlen_off) else getString(R.string.minlen_n, m)
        val n = Prefs.excluded(this).size
        vFolders.text = if (n == 0) getString(R.string.folders_none) else getString(R.string.folders_n, n)
        vSort.text = getString(
            when (Prefs.sort(this)) {
                1 -> R.string.sort_artist
                2 -> R.string.sort_recent
                else -> R.string.sort_title
            }
        )
        vSleep.text = getString(R.string.sleep_min, Prefs.sleepDefault(this))
    }

    // ---------- dialog ----------
    private fun pickTheme() {
        val labels = arrayOf(getString(R.string.theme_system), getString(R.string.theme_light), getString(R.string.theme_dark))
        AlertDialog.Builder(this)
            .setTitle(R.string.set_theme)
            .setSingleChoiceItems(labels, Prefs.theme(this)) { d, which ->
                Prefs.setTheme(this, which)
                d.dismiss()
                recreate()
            }
            .show()
    }

    private fun pickMinLen() {
        val vals = intArrayOf(0, 15, 30, 60)
        val labels = Array(vals.size) { i ->
            if (vals[i] == 0) getString(R.string.minlen_off) else getString(R.string.minlen_n, vals[i])
        }
        val cur = vals.indexOf(Prefs.minSec(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(R.string.set_minlen)
            .setSingleChoiceItems(labels, cur) { d, which ->
                Prefs.setMinSec(this, vals[which])
                d.dismiss()
                updateValues()
            }
            .show()
    }

    private fun pickSort() {
        val labels = arrayOf(getString(R.string.sort_title), getString(R.string.sort_artist), getString(R.string.sort_recent))
        AlertDialog.Builder(this)
            .setTitle(R.string.set_sort)
            .setSingleChoiceItems(labels, Prefs.sort(this)) { d, which ->
                Prefs.setSort(this, which)
                d.dismiss()
                updateValues()
            }
            .show()
    }

    private fun pickSleep() {
        val vals = intArrayOf(15, 30, 45, 60)
        val labels = Array(vals.size) { i -> getString(R.string.sleep_min, vals[i]) }
        val cur = vals.indexOf(Prefs.sleepDefault(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(R.string.set_sleepdef)
            .setSingleChoiceItems(labels, cur) { d, which ->
                Prefs.setSleepDefault(this, vals[which])
                d.dismiss()
                updateValues()
            }
            .show()
    }

    private fun shortPath(p: String): String {
        val root = "/storage/emulated/0/"
        return if (p.startsWith(root)) p.substring(root.length) else p
    }

    private fun pickFolders() {
        val app = applicationContext
        Thread {
            val list = Library.folders(app)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (list.isEmpty()) {
                    Toast.makeText(this, R.string.folders_empty, Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val sel = HashSet<String>(Prefs.excluded(this))
                val labels = Array(list.size) { i -> shortPath(list[i].path) + " (" + list[i].count + ")" }
                val checked = BooleanArray(list.size) { i -> sel.contains(list[i].path) }
                AlertDialog.Builder(this)
                    .setTitle(R.string.set_folders)
                    .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                        if (isChecked) sel.add(list[which].path) else sel.remove(list[which].path)
                    }
                    .setPositiveButton(R.string.ok) { _, _ ->
                        Prefs.setExcluded(this, sel)
                        updateValues()
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }.start()
    }

    private fun reloadLibrary() {
        val app = applicationContext
        Thread {
            val n = Library.load(app).size
            runOnUiThread {
                if (!isFinishing) Toast.makeText(this, getString(R.string.reloaded, n), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun confirmClearFavs() {
        AlertDialog.Builder(this)
            .setMessage(R.string.clearfav_q)
            .setPositiveButton(R.string.delete_label) { _, _ ->
                Prefs.clearFavs(this)
                Toast.makeText(this, R.string.clearfav_done, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showAbout() {
        var ver = ""
        try {
            ver = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name) + " v" + ver)
            .setMessage(R.string.about_body)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }
}
