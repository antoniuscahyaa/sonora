package com.sonora.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Player.init(this)
    }
}
