package com.sonora.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.io.File

/** Avatar pengguna: foto dari galeri (disimpan di dalam aplikasi) atau inisial dengan warna pilihan. */
object Avatar {
    private val BGS = intArrayOf(
        Color.argb(51, 255, 255, 255),
        Color.parseColor("#93C5FD"),
        Color.parseColor("#6EE7B7"),
        Color.parseColor("#C4B5FD"),
        Color.parseColor("#FDBA74")
    )
    private val DARK_TEXT = Color.parseColor("#1E293B")

    private var cache: Bitmap? = null
    private var cacheStamp = ""

    private fun file(c: Context) = File(c.filesDir, "avatar.jpg")

    fun has(c: Context): Boolean = file(c).exists()

    private fun idx(c: Context): Int = Prefs.avatarColor(c).coerceIn(0, BGS.size - 1)

    fun bg(c: Context): Int = BGS[idx(c)]

    fun fg(c: Context): Int = if (idx(c) == 0) Color.WHITE else DARK_TEXT

    fun bitmap(c: Context): Bitmap? {
        val f = file(c)
        if (!f.exists()) {
            cache = null
            cacheStamp = ""
            return null
        }
        val stamp = f.lastModified().toString() + ":" + f.length()
        if (cache != null && stamp == cacheStamp) return cache
        cache = try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
        cacheStamp = stamp
        return cache
    }

    fun remove(c: Context) {
        file(c).delete()
        cache = null
        cacheStamp = ""
    }

    /** Membaca foto, memotong persegi di tengah, memperkecil ke 512 px, lalu menyimpannya. */
    fun saveFrom(c: Context, uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
            while (maxSide / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var src = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false

            var rot = 0
            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    c.contentResolver.openInputStream(uri)?.use {
                        val ex = android.media.ExifInterface(it)
                        rot = when (ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                            else -> 0
                        }
                    }
                } catch (e: Exception) {
                }
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                src = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            }
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 512, 512, true)
            file(c).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            cache = null
            cacheStamp = ""
            return true
        } catch (e: Exception) {
            return false
        } catch (e: OutOfMemoryError) {
            return false
        }
    }

    /** Menu avatar: pilih foto, ganti warna inisial, hapus foto. */
    fun showMenu(act: BaseActivity, onChanged: () -> Unit) {
        act.onAvatarChanged = onChanged
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(act.getString(R.string.avatar_pick))
        acts.add { act.pickAvatar() }
        labels.add(act.getString(R.string.avatar_color))
        acts.add { showColors(act, onChanged) }
        if (has(act)) {
            labels.add(act.getString(R.string.avatar_remove))
            acts.add {
                remove(act)
                onChanged()
            }
        }
        AlertDialog.Builder(act)
            .setTitle(R.string.avatar_title)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    private fun showColors(act: BaseActivity, onChanged: () -> Unit) {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER
        row.setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(4))
        val cur = idx(act)
        val ink = act.col(R.color.ink)
        var dialog: AlertDialog? = null
        for (i in BGS.indices) {
            val cell = FrameLayout(act)
            val ring = act.ov(BLUE)
            if (i == cur) ring.setStroke(act.dp(3), ink)
            cell.background = ring
            val dot = View(act)
            dot.background = act.ov(BGS[i])
            cell.addView(dot, FrameLayout.LayoutParams(act.dp(30), act.dp(30), Gravity.CENTER))
            cell.setOnClickListener {
                Prefs.setAvatarColor(act, i)
                dialog?.dismiss()
                onChanged()
            }
            row.addView(cell, LinearLayout.LayoutParams(act.dp(46), act.dp(46)).apply { marginStart = act.dp(5); marginEnd = act.dp(5) })
        }
        dialog = AlertDialog.Builder(act)
            .setTitle(R.string.avatar_color_title)
            .setView(row)
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
