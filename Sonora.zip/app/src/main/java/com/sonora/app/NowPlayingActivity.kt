package com.sonora.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

private class Pill(val root: LinearLayout, val ic: ImageView, val tv: TextView)

class NowPlayingActivity : BaseActivity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val SURF by lazy { col(R.color.surf) }
    private val LINK by lazy { col(R.color.link) }

    private lateinit var art: ArtView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var seek: SeekBar
    private lateinit var playIc: ImageView
    private lateinit var shuffleIc: ImageView
    private lateinit var repeatIc: ImageView
    private lateinit var favPill: Pill
    private lateinit var sleepPill: Pill
    private val main = Handler(Looper.getMainLooper())
    private var dragging = false
    private var shownId = -1L

    private val listener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            main.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
    }

    override fun onStart() {
        super.onStart()
        Player.addListener(listener)
        render()
        main.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        Player.removeListener(listener)
        main.removeCallbacks(ticker)
    }

    private fun build(): View {
        val dm = resources.displayMetrics
        val white88 = Color.argb(224, 255, 255, 255)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = HeaderBg(0f)

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(16), dp(8), dp(16), 0)
        top.addView(glassBtn(R.drawable.ic_chevron_down, getString(R.string.back)) { finish() }, LinearLayout.LayoutParams(dp(40), dp(40)))
        val chipTv = TextView(this)
        chipTv.text = getString(R.string.now_playing)
        chipTv.textSize = 14f
        chipTv.setTextColor(Color.WHITE)
        chipTv.background = rr(Color.argb(46, 255, 255, 255), 16)
        chipTv.setPadding(dp(14), dp(6), dp(14), dp(6))
        val mid = FrameLayout(this)
        mid.addView(chipTv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        top.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(View(this), LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val artPx = minOf(dm.widthPixels - dp(96), (dm.heightPixels * 0.30f).toInt())
        val artDp = (artPx / dm.density).toInt()
        art = ArtView(this, artDp, 32)
        val artBox = FrameLayout(this)
        artBox.addView(art, FrameLayout.LayoutParams(dp(artDp), dp(artDp), Gravity.CENTER))
        root.addView(artBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(24), 0, dp(24), dp(12))
        titleTv = TextView(this)
        titleTv.textSize = 28f
        titleTv.setTextColor(Color.WHITE)
        titleTv.setTypeface(null, Typeface.BOLD)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        artistTv = TextView(this)
        artistTv.textSize = 16f
        artistTv.setTextColor(white88)
        artistTv.maxLines = 1
        artistTv.ellipsize = TextUtils.TruncateAt.END
        info.addView(titleTv, LinearLayout.LayoutParams(MATCH, WRAP))
        info.addView(artistTv, LinearLayout.LayoutParams(MATCH, WRAP))

        seek = SeekBar(this)
        seek.max = 1000
        seek.setPadding(dp(8), 0, dp(8), 0)
        seek.progressTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(64, 255, 255, 255))
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tCur.text = fmt(Player.duration() * progress / 1000)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                val p = sb?.progress ?: 0
                Player.seekTo((Player.duration() * p / 1000).toInt())
            }
        })
        info.addView(seek, LinearLayout.LayoutParams(MATCH, dp(32)).apply { topMargin = dp(10) })
        val times = LinearLayout(this)
        tCur = TextView(this)
        tCur.textSize = 13f
        tCur.setTextColor(white88)
        tTot = TextView(this)
        tTot.textSize = 13f
        tTot.setTextColor(white88)
        tTot.gravity = Gravity.END
        times.addView(tCur, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(tTot, LinearLayout.LayoutParams(0, WRAP, 1f))
        info.addView(times, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(info, LinearLayout.LayoutParams(MATCH, WRAP))

        val r = dp(34).toFloat()
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        val pbg = GradientDrawable()
        pbg.setColor(BG)
        pbg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = pbg
        panel.setPadding(dp(16), dp(20), dp(16), dp(18))

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER_VERTICAL
        shuffleIc = icon(R.drawable.ic_shuffle, MUTED)
        repeatIc = icon(R.drawable.ic_repeat, MUTED)
        playIc = icon(R.drawable.ic_play, Color.WHITE)
        ctl.addView(wrapCtl(shuffleIc, 24) { Player.toggleShuffle() }, LinearLayout.LayoutParams(0, dp(56), 1f))
        ctl.addView(wrapCtl(icon(R.drawable.ic_prev, INK), 30) { Player.prev() }, LinearLayout.LayoutParams(0, dp(56), 1f))
        val pb = FrameLayout(this)
        pb.background = ov(BLUE)
        pb.contentDescription = getString(R.string.play)
        pb.addView(playIc, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        pb.setOnClickListener { Player.toggle() }
        ctl.addView(pb, LinearLayout.LayoutParams(dp(72), dp(72)))
        ctl.addView(wrapCtl(icon(R.drawable.ic_next, INK), 30) { Player.next() }, LinearLayout.LayoutParams(0, dp(56), 1f))
        ctl.addView(wrapCtl(repeatIc, 24) { Player.cycleRepeat() }, LinearLayout.LayoutParams(0, dp(56), 1f))
        panel.addView(ctl, LinearLayout.LayoutParams(MATCH, WRAP))

        val pills = LinearLayout(this)
        pills.gravity = Gravity.CENTER
        favPill = pill(R.drawable.ic_heart_outline, getString(R.string.chip_fav)) {
            val t = Player.current
            if (t != null) {
                Prefs.toggleFav(this, t.id)
                render()
            }
        }
        sleepPill = pill(R.drawable.ic_moon, getString(R.string.sleep_timer)) { showSleepDialog() }
        val queuePill = pill(R.drawable.ic_queue, getString(R.string.queue)) {
            startActivity(Intent(this, QueueActivity::class.java))
        }
        for (p in listOf(favPill, sleepPill, queuePill)) {
            setPill(p, false)
            pills.addView(p.root, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        panel.addView(pills, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })
        root.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        return root
    }

    private fun wrapCtl(iv: ImageView, sizeDp: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.addView(iv, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        return f
    }

    private fun pill(res: Int, label: String, onClick: () -> Unit): Pill {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER
        l.setPadding(dp(8), 0, dp(8), 0)
        val ic = icon(res, INK)
        l.addView(ic, LinearLayout.LayoutParams(dp(17), dp(17)))
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(5), 0, 0, 0)
        l.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
        l.setOnClickListener { onClick() }
        return Pill(l, ic, tv)
    }

    private fun setPill(p: Pill, on: Boolean) {
        p.root.background = rr(if (on) BLUE else SURF, 20)
        val c = if (on) Color.WHITE else INK
        p.tv.setTextColor(c)
        p.ic.setColorFilter(c, PorterDuff.Mode.SRC_IN)
    }

    private fun showSleepDialog() {
        val def = Prefs.sleepDefault(this)
        val labels = arrayOf(
            getString(R.string.sleep_default, def),
            getString(R.string.sleep_min, 15), getString(R.string.sleep_min, 30),
            getString(R.string.sleep_min, 45), getString(R.string.sleep_min, 60),
            getString(R.string.sleep_song),
            getString(R.string.sleep_off)
        )
        val mins = intArrayOf(def, 15, 30, 45, 60)
        AlertDialog.Builder(this)
            .setTitle(R.string.sleep_timer)
            .setItems(labels) { _, which ->
                when {
                    which < mins.size -> Player.setSleep(mins[which])
                    which == mins.size -> Player.sleepAfterSong()
                    else -> Player.setSleep(0)
                }
            }
            .show()
    }

    private fun render() {
        val t = Player.current
        if (t == null) {
            finish()
            return
        }
        if (shownId != t.id) {
            shownId = t.id
            art.bind(t)
        }
        titleTv.text = t.title
        artistTv.text = t.artist
        tTot.text = fmt(t.durationMs)
        playIc.setImageResource(if (Player.playing) R.drawable.ic_pause else R.drawable.ic_play)
        shuffleIc.setColorFilter(if (Player.shuffle) LINK else MUTED, PorterDuff.Mode.SRC_IN)
        repeatIc.setImageResource(if (Player.repeat == 2) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatIc.setColorFilter(if (Player.repeat != 0) LINK else MUTED, PorterDuff.Mode.SRC_IN)
        val fav = Prefs.isFav(this, t.id)
        favPill.ic.setImageResource(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline)
        setPill(favPill, fav)
        setPill(sleepPill, Player.sleepAt > 0L || Player.sleepWaiting)
        tick()
    }

    private fun tick() {
        if (dragging) return
        val d = Player.duration()
        val pos = Player.position().toLong()
        seek.progress = if (d > 0) (pos * 1000 / d).toInt() else 0
        tCur.text = fmt(pos)
    }
}
