package com.sonora.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import java.util.concurrent.Executors

object Art {
    private val cache = LruCache<String, Bitmap>(80)
    private val none = HashSet<String>()
    private val ex = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private fun key(t: Track, px: Int): String =
        (if (t.albumId != 0L) "a" + t.albumId else "t" + t.id) + "_" + px

    fun load(ctx: Context, t: Track, px: Int, done: (Bitmap?) -> Unit) {
        val k = key(t, px)
        val hit = cache.get(k)
        if (hit != null) {
            done(hit)
            return
        }
        if (none.contains(k)) {
            done(null)
            return
        }
        val app = ctx.applicationContext
        ex.execute {
            val b = decode(app, t, px)
            main.post {
                if (b != null) cache.put(k, b) else none.add(k)
                done(b)
            }
        }
    }

    private fun decode(ctx: Context, t: Track, px: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(t.uri, Size(px, px), null)
            } else {
                val u = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId)
                ctx.contentResolver.openFileDescriptor(u, "r")?.use { pfd ->
                    val raw = BitmapFactory.decodeFileDescriptor(pfd.fileDescriptor)
                    if (raw != null) Bitmap.createScaledBitmap(raw, px, px, true) else null
                }
            }
        } catch (e: Exception) {
            null
        }
    }
}

private val PAL = intArrayOf(
    Color.parseColor("#1D4ED8"), Color.parseColor("#0F7A41"), Color.parseColor("#6D28D9"),
    Color.parseColor("#B45309"), Color.parseColor("#B42318")
)

/** Sampul lagu dengan sudut membulat; jika tidak ada sampul, tampil warna + ikon not. */
class ArtView(ctx: Context, sizeDp: Int, radiusDp: Int) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    private val note = ImageView(ctx)
    private val px = ctx.dp(sizeDp)
    var boundId: Long = -1L
        private set

    init {
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        note.setImageResource(R.drawable.ic_music)
        val ns = ctx.dp(sizeDp) / 2
        addView(note, FrameLayout.LayoutParams(ns, ns, Gravity.CENTER))
        addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val r = ctx.dp(radiusDp).toFloat()
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        clipToOutline = true
        setBackgroundColor(PAL[0])
    }

    fun bind(t: Track?) {
        boundId = t?.id ?: -1L
        img.setImageDrawable(null)
        img.visibility = View.GONE
        note.visibility = View.VISIBLE
        if (t == null) return
        val k = if (t.albumId != 0L) t.albumId else t.id
        setBackgroundColor(PAL[(k % PAL.size).toInt()])
        Art.load(context, t, px) { bmp ->
            if (boundId == t.id && bmp != null) {
                img.setImageBitmap(bmp)
                img.visibility = View.VISIBLE
                note.visibility = View.GONE
            }
        }
    }
}
