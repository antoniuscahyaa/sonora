package com.sonora.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder

/** Menjaga pemutaran tetap hidup di latar belakang + notifikasi media. */
class PlaybackService : Service() {
    companion object {
        @Volatile
        var running = false
        const val CH = "sonora_playback"
        const val ID = 1
        const val A_TOGGLE = "com.sonora.app.TOGGLE"
        const val A_NEXT = "com.sonora.app.NEXT"
        const val A_PREV = "com.sonora.app.PREV"
    }

    private lateinit var session: MediaSession
    private lateinit var nm: NotificationManager
    private var fg = false
    private val listener: () -> Unit = { refresh() }
    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (Prefs.pauseOnUnplug(this@PlaybackService) && Player.playing) Player.pause(true)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        running = true
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        session = MediaSession(this, "Sonora")
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { Player.play() }
            override fun onPause() { Player.pause() }
            override fun onSkipToNext() { Player.next() }
            override fun onSkipToPrevious() { Player.prev() }
            override fun onSeekTo(pos: Long) { Player.seekTo(pos.toInt()) }
        })
        session.isActive = true
        Player.addListener(listener)
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_TOGGLE -> Player.toggle()
            A_NEXT -> Player.next()
            A_PREV -> Player.prev()
        }
        // Wajib memanggil startForeground secepatnya setelah dimulai.
        startFg(build(Player.current))
        refresh()
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!Player.playing) {
            nm.cancel(ID)
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        Player.removeListener(listener)
        try {
            unregisterReceiver(noisy)
        } catch (e: Exception) {
        }
        session.isActive = false
        session.release()
        super.onDestroy()
    }

    private fun startFg(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(ID, n)
            }
            fg = true
        } catch (e: Exception) {
            nm.notify(ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        val t = Player.current
        if (t == null) {
            stopForeground(true)
            fg = false
            stopSelf()
            return
        }
        session.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs)
                .build()
        )
        val st = if (Player.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
        session.setPlaybackState(
            PlaybackState.Builder().setActions(actions).setState(st, Player.position().toLong(), 1f).build()
        )
        val n = build(t)
        if (Player.playing) {
            if (fg) nm.notify(ID, n) else startFg(n)
        } else {
            if (fg) {
                stopForeground(false)
                fg = false
            }
            nm.notify(ID, n)
        }
    }

    private fun svc(action: String): PendingIntent {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        return PendingIntent.getService(this, action.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    @Suppress("DEPRECATION")
    private fun build(t: Track?): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, NowPlayingActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(t?.title ?: getString(R.string.app_name))
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(Player.playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        b.addAction(R.drawable.ic_prev, getString(R.string.prev), svc(A_PREV))
        b.addAction(
            if (Player.playing) R.drawable.ic_pause else R.drawable.ic_play,
            getString(if (Player.playing) R.string.pause else R.string.play),
            svc(A_TOGGLE)
        )
        b.addAction(R.drawable.ic_next, getString(R.string.next), svc(A_NEXT))
        b.setStyle(
            Notification.MediaStyle()
                .setMediaSession(session.sessionToken)
                .setShowActionsInCompactView(0, 1, 2)
        )
        return b.build()
    }
}
