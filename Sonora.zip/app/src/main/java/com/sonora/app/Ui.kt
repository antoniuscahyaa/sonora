package com.sonora.app

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

val BLUE: Int = Color.parseColor("#1D4ED8")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

@Suppress("DEPRECATION")
fun Context.col(id: Int): Int = resources.getColor(id)

fun Context.rr(color: Int, r: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    return g
}

fun Context.ov(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

fun Context.icon(res: Int, color: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    return v
}

fun Context.tinted(res: Int, color: Int, sizeDp: Int): Drawable {
    val d = getDrawable(res)!!.mutate()
    d.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    d.setBounds(0, 0, dp(sizeDp), dp(sizeDp))
    return d
}

/** Tombol lingkaran kaca untuk header biru. */
fun Context.glassBtn(res: Int, desc: String, onClick: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    f.background = ov(Color.argb(46, 255, 255, 255))
    f.contentDescription = desc
    f.isClickable = true
    f.addView(icon(res, Color.WHITE), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
    f.setOnClickListener { onClick() }
    return f
}

val Context.isDark: Boolean
    get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

@Suppress("DEPRECATION")
fun Activity.styleBars(nav: Int) {
    window.statusBarColor = BLUE
    window.navigationBarColor = nav
    if (Build.VERSION.SDK_INT >= 26 && !isDark) {
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
}
