package com.sonora.app

import android.content.Context
import android.provider.MediaStore

object Library {
    fun load(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val unknownArtist = ctx.getString(R.string.unknown_artist)
        val unknownAlbum = ctx.getString(R.string.unknown_album)
        val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " >= 30000"
        try {
            ctx.contentResolver.query(m, proj, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)
                    val album = c.getString(3)
                    out.add(
                        Track(
                            id = c.getLong(0),
                            title = c.getString(1) ?: "",
                            artist = if (artist.isNullOrBlank() || artist == MediaStore.UNKNOWN_STRING) unknownArtist else artist,
                            album = if (album.isNullOrBlank() || album == MediaStore.UNKNOWN_STRING) unknownAlbum else album,
                            albumId = c.getLong(4),
                            durationMs = c.getLong(5),
                            added = c.getLong(6)
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }
        return out
    }
}
