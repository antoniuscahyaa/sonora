package com.sonora.app

import android.content.Context
import android.provider.MediaStore

class Folder(val path: String, val count: Int)

object Library {
    /** Nama artis yang memang memakai tanda pemisah dan tidak boleh dipecah. */
    private val KEEP = listOf("ac/dc", "m/a/r/r/s")
    private val SEPS = listOf("/", ";", " feat. ", " feat ", " ft. ")

    fun mainArtist(raw: String): String {
        val low = raw.lowercase()
        for (e in KEEP) {
            if (low == e || low.startsWith("$e/") || low.startsWith("$e;")) return raw.substring(0, e.length)
        }
        var cut = raw.length
        for (sep in SEPS) {
            val i = raw.indexOf(sep, 0, true)
            if (i > 0 && i < cut) cut = i
        }
        val r = raw.substring(0, cut).trim()
        return if (r.isEmpty()) raw else r
    }

    private fun dirOf(path: String): String {
        val i = path.lastIndexOf('/')
        return if (i > 0) path.substring(0, i) else ""
    }

    private fun isExcluded(path: String, excl: Set<String>): Boolean {
        if (excl.isEmpty() || path.isEmpty()) return false
        for (d in excl) {
            if (path.startsWith("$d/")) return true
        }
        return false
    }

    fun load(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val unknownArtist = ctx.getString(R.string.unknown_artist)
        val unknownAlbum = ctx.getString(R.string.unknown_album)
        val minMs = Prefs.minSec(ctx) * 1000L
        val excl = Prefs.excluded(ctx)
        val merge = Prefs.mergeArtists(ctx)
        val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        @Suppress("DEPRECATION")
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA
        )
        val sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " >= " + minMs
        try {
            ctx.contentResolver.query(m, proj, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) {
                    val path = c.getString(7) ?: ""
                    if (isExcluded(path, excl)) continue
                    val artist = c.getString(2)
                    val album = c.getString(3)
                    val a = if (artist.isNullOrBlank() || artist == MediaStore.UNKNOWN_STRING) unknownArtist else artist
                    out.add(
                        Track(
                            id = c.getLong(0),
                            title = c.getString(1) ?: "",
                            artist = a,
                            album = if (album.isNullOrBlank() || album == MediaStore.UNKNOWN_STRING) unknownAlbum else album,
                            albumId = c.getLong(4),
                            durationMs = c.getLong(5),
                            added = c.getLong(6),
                            path = path,
                            groupArtist = if (merge) mainArtist(a) else a
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }
        return when (Prefs.sort(ctx)) {
            1 -> out.sortedWith(compareBy<Track>({ it.artist.lowercase() }, { it.title.lowercase() }))
            2 -> out.sortedByDescending { it.added }
            else -> out
        }
    }

    /** Daftar folder yang berisi musik (tanpa memperhatikan folder yang dikecualikan). */
    fun folders(ctx: Context): List<Folder> {
        val counts = HashMap<String, Int>()
        @Suppress("DEPRECATION")
        val proj = arrayOf(MediaStore.Audio.Media.DATA)
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.Audio.Media.IS_MUSIC + " != 0", null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val d = dirOf(c.getString(0) ?: "")
                    if (d.isNotEmpty()) counts[d] = (counts[d] ?: 0) + 1
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }
        return counts.map { Folder(it.key, it.value) }.sortedBy { it.path.lowercase() }
    }
}
