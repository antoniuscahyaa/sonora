package com.sonora.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class Item(val title: String, val sub: String, val track: Track?, val group: Boolean, val key: String)

class RowHolder(
    val root: LinearLayout, val art: ArtView, val t1: TextView, val t2: TextView,
    val btn: FrameLayout, val btnIcon: ImageView, val chev: ImageView
)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val SURF by lazy { col(R.color.surf) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }

    private var all: List<Track> = emptyList()
    private var tab = 0 // 0 lagu, 1 album, 2 artis
    private var chip = 0 // 0 semua, 1 favorit, 2 terbaru
    private var query = ""
    private var drillKind = 0 // 0 tidak, 1 album, 2 artis
    private var drillKey = ""
    private var drillTitle = ""
    private var items: List<Item> = emptyList()
    private var songsShown: List<Track> = emptyList()

    private lateinit var titleTv: TextView
    private lateinit var backBtn: FrameLayout
    private lateinit var chipsRow: LinearLayout
    private val chipTvs = ArrayList<TextView>()
    private lateinit var list: ListView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var grantBtn: TextView
    private lateinit var mini: FrameLayout
    private lateinit var miniArt: ArtView
    private lateinit var miniT1: TextView
    private lateinit var miniT2: TextView
    private lateinit var miniPlayIc: ImageView
    private lateinit var miniBar: View
    private val tabPills = ArrayList<FrameLayout>()
    private val tabIcons = ArrayList<ImageView>()
    private val tabLbls = ArrayList<TextView>()
    private val main = Handler(Looper.getMainLooper())

    private val listener: () -> Unit = {
        adapter.notifyDataSetChanged()
        updateMini()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (Player.playing) updateBar()
            main.postDelayed(this, 500)
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h = (convertView?.tag as? RowHolder) ?: makeRow()
            bindRow(h, items[position])
            return h.root
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
        refresh()
        if (!hasPerm()) askPerm()
    }

    override fun onStart() {
        super.onStart()
        Player.addListener(listener)
        load()
        main.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        Player.removeListener(listener)
        main.removeCallbacks(ticker)
    }

    override fun onBackPressed() {
        if (drillKind != 0) {
            drillKind = 0
            refresh()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- izin & data ----------
    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun askPerm() {
        if (Build.VERSION.SDK_INT < 23) return
        val l = arrayListOf(audioPerm())
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(l.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        load()
    }

    private fun load() {
        if (!hasPerm()) {
            all = emptyList()
            refresh()
            return
        }
        val app = applicationContext
        Thread {
            val l = Library.load(app)
            runOnUiThread {
                all = l
                refresh()
            }
        }.start()
    }

    // ---------- UI ----------
    private fun build(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.isFocusableInTouchMode = true
        root.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
        root.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))

        val body = FrameLayout(this)
        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.setPadding(0, dp(8), 0, dp(8))
        list.clipToPadding = false
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onRow(items[pos]) }
        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        emptyBox.setPadding(dp(32), dp(32), dp(32), dp(32))
        emptyTitle = TextView(this)
        emptyTitle.textSize = 20f
        emptyTitle.setTypeface(null, Typeface.BOLD)
        emptyTitle.setTextColor(INK)
        emptyTitle.gravity = Gravity.CENTER
        emptyBody = TextView(this)
        emptyBody.textSize = 14f
        emptyBody.setTextColor(MUTED)
        emptyBody.gravity = Gravity.CENTER
        emptyBody.setPadding(0, dp(6), 0, 0)
        grantBtn = TextView(this)
        grantBtn.text = getString(R.string.grant)
        grantBtn.textSize = 16f
        grantBtn.setTextColor(Color.WHITE)
        grantBtn.setTypeface(null, Typeface.BOLD)
        grantBtn.gravity = Gravity.CENTER
        grantBtn.background = rr(BLUE, 28)
        grantBtn.setPadding(dp(28), dp(14), dp(28), dp(14))
        grantBtn.setOnClickListener { askPerm() }
        emptyBox.addView(emptyTitle, LinearLayout.LayoutParams(MATCH, WRAP))
        emptyBox.addView(emptyBody, LinearLayout.LayoutParams(MATCH, WRAP))
        emptyBox.addView(grantBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
        body.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(emptyBox, FrameLayout.LayoutParams(MATCH, MATCH))
        list.emptyView = emptyBox
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(buildMini())
        root.addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        return root
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.VERTICAL
        val r = dp(36).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BLUE)
        bg.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        h.background = bg
        h.setPadding(dp(16), dp(8), dp(16), dp(16))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        backBtn = glassBtn(R.drawable.ic_back, getString(R.string.back)) { onBackPressed() }
        backBtn.visibility = View.GONE
        top.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) })
        titleTv = TextView(this)
        titleTv.textSize = 28f
        titleTv.setTextColor(Color.WHITE)
        titleTv.setTypeface(null, Typeface.BOLD)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        top.addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(
            glassBtn(R.drawable.ic_shuffle, getString(R.string.shuffle_all)) { shuffleAll() },
            LinearLayout.LayoutParams(dp(44), dp(44))
        )
        h.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })

        val et = EditText(this)
        et.hint = getString(R.string.search_hint)
        et.textSize = 15f
        et.setTextColor(Color.parseColor("#14181F"))
        et.setHintTextColor(Color.parseColor("#5B6472"))
        et.background = rr(Color.WHITE, 24)
        et.setPadding(dp(16), 0, dp(16), 0)
        et.setSingleLine()
        et.compoundDrawablePadding = dp(8)
        et.setCompoundDrawables(tinted(R.drawable.ic_search, BLUE, 20), null, null, null)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                refresh()
            }
        })
        h.addView(et, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(10) })

        chipsRow = LinearLayout(this)
        chipsRow.background = rr(Color.argb(46, 255, 255, 255), 24)
        chipsRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        val names = intArrayOf(R.string.chip_all, R.string.chip_fav, R.string.chip_recent)
        for (i in names.indices) {
            val tv = TextView(this)
            tv.text = getString(names[i])
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(null, Typeface.BOLD)
            tv.setOnClickListener {
                chip = i
                refresh()
            }
            chipTvs.add(tv)
            chipsRow.addView(tv, LinearLayout.LayoutParams(0, dp(32), 1f))
        }
        h.addView(chipsRow, LinearLayout.LayoutParams(MATCH, WRAP))
        return h
    }

    private fun buildMini(): View {
        mini = FrameLayout(this)
        mini.background = rr(SURF, 16)
        val rad = dp(16).toFloat()
        mini.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, rad)
            }
        }
        mini.clipToOutline = true
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        miniArt = ArtView(this, 40, 12)
        row.addView(miniArt, LinearLayout.LayoutParams(dp(40), dp(40)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        miniT1 = TextView(this)
        miniT1.textSize = 15f
        miniT1.setTypeface(null, Typeface.BOLD)
        miniT1.setTextColor(INK)
        miniT1.maxLines = 1
        miniT1.ellipsize = TextUtils.TruncateAt.END
        miniT2 = TextView(this)
        miniT2.textSize = 13f
        miniT2.setTextColor(MUTED)
        miniT2.maxLines = 1
        miniT2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(miniT1)
        tx.addView(miniT2)
        row.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(10); marginEnd = dp(8) })
        val pb = FrameLayout(this)
        pb.background = ov(BLUE)
        pb.contentDescription = getString(R.string.play)
        miniPlayIc = icon(R.drawable.ic_play, Color.WHITE)
        pb.addView(miniPlayIc, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        pb.setOnClickListener { Player.toggle() }
        row.addView(pb, LinearLayout.LayoutParams(dp(40), dp(40)))
        val nx = FrameLayout(this)
        nx.contentDescription = getString(R.string.next)
        nx.addView(icon(R.drawable.ic_next, INK), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        nx.setOnClickListener { Player.next() }
        row.addView(nx, LinearLayout.LayoutParams(dp(40), dp(40)))
        miniBar = View(this)
        miniBar.setBackgroundColor(BLUE)
        mini.addView(row, FrameLayout.LayoutParams(MATCH, WRAP))
        mini.addView(miniBar, FrameLayout.LayoutParams(0, dp(3), Gravity.BOTTOM or Gravity.START))
        mini.setOnClickListener { startActivity(Intent(this, NowPlayingActivity::class.java)) }
        mini.visibility = View.GONE
        mini.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) }
        return mini
    }

    private fun buildNav(): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setBackgroundColor(BG)
        val line = View(this)
        line.setBackgroundColor(LINE)
        wrap.addView(line, LinearLayout.LayoutParams(MATCH, dp(1)))
        val row = LinearLayout(this)
        val icons = intArrayOf(R.drawable.ic_music, R.drawable.ic_album, R.drawable.ic_person)
        val labels = intArrayOf(R.string.tab_songs, R.string.tab_albums, R.string.tab_artists)
        for (k in 0..2) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            val pill = FrameLayout(this)
            val iv = icon(icons[k], MUTED)
            pill.addView(iv, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            cell.addView(pill, LinearLayout.LayoutParams(dp(56), dp(28)))
            val tv = TextView(this)
            tv.text = getString(labels[k])
            tv.textSize = 12f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(MUTED)
            tv.setPadding(0, dp(4), 0, 0)
            cell.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
            cell.setOnClickListener {
                tab = k
                drillKind = 0
                refresh()
            }
            tabPills.add(pill)
            tabIcons.add(iv)
            tabLbls.add(tv)
            row.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        wrap.addView(row, LinearLayout.LayoutParams(MATCH, dp(72)))
        return wrap
    }

    private fun makeRow(): RowHolder {
        val root = LinearLayout(this)
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(8))
        val art = ArtView(this, 48, 14)
        root.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.textSize = 16f
        t1.setTypeface(null, Typeface.BOLD)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val t2 = TextView(this)
        t2.textSize = 13f
        t2.setTextColor(MUTED)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(t1)
        tx.addView(t2)
        root.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(12) })
        val btn = FrameLayout(this)
        btn.background = ov(BLUE)
        val bi = icon(R.drawable.ic_play, Color.WHITE)
        btn.addView(bi, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        root.addView(btn, LinearLayout.LayoutParams(dp(44), dp(44)))
        val chev = icon(R.drawable.ic_chevron, MUTED)
        root.addView(chev, LinearLayout.LayoutParams(dp(24), dp(24)))
        val h = RowHolder(root, art, t1, t2, btn, bi, chev)
        root.tag = h
        return h
    }

    private fun bindRow(h: RowHolder, item: Item) {
        h.art.bind(item.track)
        val cur = Player.current
        val isCur = !item.group && cur != null && item.track?.id == cur.id
        h.t1.text = item.title
        h.t1.setTextColor(if (isCur) LINK else INK)
        h.t2.text = item.sub
        h.btn.visibility = if (item.group) View.GONE else View.VISIBLE
        h.chev.visibility = if (item.group) View.VISIBLE else View.GONE
        if (!item.group) {
            h.btnIcon.setImageResource(if (isCur && Player.playing) R.drawable.ic_pause else R.drawable.ic_play)
        }
    }

    // ---------- logika ----------
    private fun songItem(t: Track) = Item(t.title, t.artist + " · " + fmt(t.durationMs), t, false, t.id.toString())

    private fun compute() {
        val q = query.trim().lowercase()
        val fav = Prefs.favs(this)
        fun match(t: Track): Boolean =
            q.isEmpty() || t.title.lowercase().contains(q) || t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)

        if (drillKind != 0) {
            val l = all.filter { t ->
                val k = if (drillKind == 1) t.albumId.toString() else t.artist
                k == drillKey && match(t)
            }
            songsShown = l
            items = l.map { songItem(it) }
            return
        }
        when (tab) {
            0 -> {
                var l = all.filter { match(it) }
                if (chip == 1) l = l.filter { fav.contains(it.id) }
                if (chip == 2) l = l.sortedByDescending { it.added }.take(50)
                songsShown = l
                items = l.map { songItem(it) }
            }
            1 -> {
                songsShown = emptyList()
                items = all.filter { match(it) }.groupBy { it.albumId }.map { e ->
                    val ts = e.value
                    Item(ts[0].album, ts[0].artist + " · " + getString(R.string.songs_count, ts.size), ts[0], true, e.key.toString())
                }.sortedBy { it.title.lowercase() }
            }
            else -> {
                songsShown = emptyList()
                items = all.filter { match(it) }.groupBy { it.artist }.map { e ->
                    val ts = e.value
                    Item(e.key, getString(R.string.songs_count, ts.size), ts[0], true, e.key)
                }.sortedBy { it.title.lowercase() }
            }
        }
    }

    private fun refresh() {
        compute()
        titleTv.text = if (drillKind != 0) drillTitle else getString(
            when (tab) {
                0 -> R.string.tab_songs
                1 -> R.string.tab_albums
                else -> R.string.tab_artists
            }
        )
        backBtn.visibility = if (drillKind != 0) View.VISIBLE else View.GONE
        chipsRow.visibility = if (tab == 0 && drillKind == 0) View.VISIBLE else View.GONE
        for (i in chipTvs.indices) {
            val on = i == chip
            chipTvs[i].background = if (on) rr(Color.WHITE, 20) else null
            chipTvs[i].setTextColor(if (on) BLUE else Color.WHITE)
        }
        for (k in tabPills.indices) {
            val on = k == tab
            tabPills[k].background = if (on) rr(BLUE, 14) else null
            tabIcons[k].setColorFilter(if (on) Color.WHITE else MUTED, android.graphics.PorterDuff.Mode.SRC_IN)
            tabLbls[k].setTextColor(if (on) LINK else MUTED)
            tabLbls[k].setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
        val perm = hasPerm()
        if (!perm) {
            emptyTitle.text = getString(R.string.empty_title)
            emptyBody.text = getString(R.string.empty_body_perm)
            grantBtn.visibility = View.VISIBLE
        } else if (all.isEmpty()) {
            emptyTitle.text = getString(R.string.empty_title)
            emptyBody.text = getString(R.string.empty_body_none)
            grantBtn.visibility = View.GONE
        } else {
            emptyTitle.text = getString(R.string.no_results)
            emptyBody.text = ""
            grantBtn.visibility = View.GONE
        }
        adapter.notifyDataSetChanged()
        updateMini()
    }

    private fun onRow(item: Item) {
        if (item.group) {
            drillKind = if (tab == 1) 1 else 2
            drillKey = item.key
            drillTitle = item.title
            refresh()
            list.setSelection(0)
            return
        }
        val t = item.track ?: return
        if (Player.current?.id == t.id) {
            Player.toggle()
            return
        }
        val i = songsShown.indexOfFirst { it.id == t.id }
        Player.setQueue(songsShown, if (i < 0) 0 else i)
    }

    private fun shuffleAll() {
        val src = if (tab == 0 || drillKind != 0) songsShown else all
        if (src.isEmpty()) return
        Player.shuffleAll(src)
    }

    private fun updateMini() {
        val t = Player.current
        if (t == null) {
            mini.visibility = View.GONE
            return
        }
        mini.visibility = View.VISIBLE
        if (miniArt.boundId != t.id) miniArt.bind(t)
        miniT1.text = t.title
        miniT2.text = t.artist
        miniPlayIc.setImageResource(if (Player.playing) R.drawable.ic_pause else R.drawable.ic_play)
        updateBar()
    }

    private fun updateBar() {
        if (Player.current == null) return
        val d = Player.duration()
        val frac = if (d > 0) Player.position().toFloat() / d.toFloat() else 0f
        val lp = miniBar.layoutParams
        lp.width = (mini.width * frac.coerceIn(0f, 1f)).toInt()
        miniBar.layoutParams = lp
    }
}
