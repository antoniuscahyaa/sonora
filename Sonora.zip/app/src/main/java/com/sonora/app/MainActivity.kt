package com.sonora.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

class Item(val title: String, val sub: String, val track: Track?, val group: Boolean, val key: String)

class RowHolder(
    val root: LinearLayout, val art: ArtView, val t1: TextView, val t2: TextView,
    val btn: FrameLayout, val btnIcon: ImageView, val chev: ImageView
)

class MainActivity : BaseActivity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val SURF by lazy { col(R.color.surf) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }

    private var all: List<Track> = emptyList()
    private var tab = 0 // 0 beranda, 1 lagu, 2 album, 3 artis
    private var chip = 0 // 0 semua, 1 terbaru
    private var favOnly = false
    private var query = ""
    private var drillKind = 0 // 0 tidak, 1 album, 2 artis
    private var drillKey = ""
    private var drillTitle = ""
    private var items: List<Item> = emptyList()
    private var songsShown: List<Track> = emptyList()

    private lateinit var titleTv: TextView
    private lateinit var backBtn: FrameLayout
    private lateinit var chipsRow: LinearLayout
    private lateinit var starBtn: FrameLayout
    private lateinit var starIc: ImageView
    private lateinit var gearBtn: FrameLayout
    private lateinit var shuffleBtn: FrameLayout
    private lateinit var searchEt: EditText
    private lateinit var greetTv: TextView
    private lateinit var headerBox: LinearLayout
    private lateinit var topRow: LinearLayout
    private lateinit var avatar: FrameLayout
    private lateinit var avatarTv: TextView
    private lateinit var avatarImg: ImageView
    private lateinit var homeScroll: ScrollView
    private lateinit var homeBox: LinearLayout
    private val chipTvs = ArrayList<TextView>()
    private lateinit var list: ListView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var grantBtn: TextView
    private lateinit var mini: FrameLayout
    private lateinit var miniArt: ArtView
    private lateinit var miniT1: TextView
    private lateinit var miniT2: TextView
    private lateinit var miniPlayIc: ImageView
    private lateinit var miniBar: View
    private val tabPills = ArrayList<FrameLayout>()
    private val tabIcons = ArrayList<ImageView>()
    private val tabLbls = ArrayList<TextView>()
    private val main = Handler(Looper.getMainLooper())

    private val listener: () -> Unit = {
        adapter.notifyDataSetChanged()
        updateMini()
        if (isHome() && query.isBlank()) refreshHome()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (Player.playing) updateBar()
            main.postDelayed(this, 500)
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h = (convertView?.tag as? RowHolder) ?: makeRow()
            bindRow(h, items[position])
            return h.root
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
        refresh()
        if (!hasPerm()) askPerm()
    }

    override fun onStart() {
        super.onStart()
        Player.addListener(listener)
        load()
        main.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        Player.removeListener(listener)
        main.removeCallbacks(ticker)
    }

    override fun onBackPressed() {
        if (drillKind != 0) {
            drillKind = 0
            refresh()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- izin & data ----------
    private fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun askPerm() {
        if (Build.VERSION.SDK_INT < 23) return
        val l = arrayListOf(audioPerm())
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(l.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        load()
    }

    private fun load() {
        if (!hasPerm()) {
            all = emptyList()
            refresh()
            return
        }
        val app = applicationContext
        Thread {
            val l = Library.load(app)
            runOnUiThread {
                all = l
                Player.restore(l)
                refresh()
            }
        }.start()
    }

    // ---------- UI ----------
    private fun build(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.isFocusableInTouchMode = true
        root.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
        root.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))

        val body = FrameLayout(this)
        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.setPadding(0, dp(8), 0, dp(8))
        list.clipToPadding = false
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onRow(items[pos]) }
        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        emptyBox.setPadding(dp(32), dp(32), dp(32), dp(32))
        emptyTitle = TextView(this)
        emptyTitle.textSize = 20f
        emptyTitle.setTypeface(null, Typeface.BOLD)
        emptyTitle.setTextColor(INK)
        emptyTitle.gravity = Gravity.CENTER
        emptyBody = TextView(this)
        emptyBody.textSize = 14f
        emptyBody.setTextColor(MUTED)
        emptyBody.gravity = Gravity.CENTER
        emptyBody.setPadding(0, dp(6), 0, 0)
        grantBtn = TextView(this)
        grantBtn.text = getString(R.string.grant)
        grantBtn.textSize = 16f
        grantBtn.setTextColor(Color.WHITE)
        grantBtn.setTypeface(null, Typeface.BOLD)
        grantBtn.gravity = Gravity.CENTER
        grantBtn.background = rr(BLUE, 28)
        grantBtn.setPadding(dp(28), dp(14), dp(28), dp(14))
        grantBtn.setOnClickListener { askPerm() }
        emptyBox.addView(emptyTitle, LinearLayout.LayoutParams(MATCH, WRAP))
        emptyBox.addView(emptyBody, LinearLayout.LayoutParams(MATCH, WRAP))
        emptyBox.addView(grantBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
        body.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(emptyBox, FrameLayout.LayoutParams(MATCH, MATCH))
        list.emptyView = emptyBox
        homeBox = LinearLayout(this)
        homeBox.orientation = LinearLayout.VERTICAL
        homeBox.setPadding(0, dp(8), 0, dp(16))
        homeScroll = ScrollView(this)
        homeScroll.setBackgroundColor(BG)
        homeScroll.isVerticalScrollBarEnabled = false
        homeScroll.addView(homeBox, ViewGroup.LayoutParams(MATCH, WRAP))
        body.addView(homeScroll, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(buildMini())
        root.addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        return root
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this)
        headerBox = h
        h.orientation = LinearLayout.VERTICAL
        h.background = HeaderBg(dp(36).toFloat())
        h.setPadding(dp(16), dp(8), dp(16), dp(16))

        val top = LinearLayout(this)
        topRow = top
        top.gravity = Gravity.CENTER_VERTICAL
        backBtn = glassBtn(R.drawable.ic_back, getString(R.string.back)) { onBackPressed() }
        backBtn.visibility = View.GONE
        top.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) })
        avatar = FrameLayout(this)
        avatar.background = ov(Color.argb(51, 255, 255, 255))
        avatarTv = TextView(this)
        avatarTv.textSize = 24f
        avatarTv.setTypeface(null, Typeface.BOLD)
        avatarTv.setTextColor(Color.WHITE)
        avatarTv.gravity = Gravity.CENTER
        avatar.addView(avatarTv, FrameLayout.LayoutParams(MATCH, MATCH))
        avatarImg = ImageView(this)
        avatarImg.scaleType = ImageView.ScaleType.CENTER_CROP
        avatarImg.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        avatarImg.clipToOutline = true
        avatarImg.visibility = View.GONE
        avatar.addView(avatarImg, FrameLayout.LayoutParams(MATCH, MATCH))
        avatar.setOnClickListener { Avatar.showMenu(this) { refresh() } }
        avatar.visibility = View.GONE
        top.addView(avatar, LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(12) })
        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        greetTv = TextView(this)
        greetTv.textSize = 14f
        greetTv.setTextColor(Color.argb(230, 255, 255, 255))
        greetTv.visibility = View.GONE
        titleTv = TextView(this)
        titleTv.textSize = 28f
        titleTv.setTextColor(Color.WHITE)
        titleTv.setTypeface(null, Typeface.BOLD)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        titleBox.addView(greetTv)
        titleBox.addView(titleTv)
        top.addView(titleBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        starBtn = glassBtn(R.drawable.ic_star, getString(R.string.chip_fav)) {
            favOnly = !favOnly
            refresh()
        }
        starIc = starBtn.getChildAt(0) as ImageView
        top.addView(starBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        shuffleBtn = glassBtn(R.drawable.ic_shuffle, getString(R.string.shuffle_all)) { shuffleAll() }
        top.addView(shuffleBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        gearBtn = glassBtn(R.drawable.ic_settings, getString(R.string.settings)) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        top.addView(gearBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        h.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })

        val et = EditText(this)
        searchEt = et
        et.hint = getString(R.string.search_hint)
        et.textSize = 15f
        et.setTextColor(Color.parseColor("#14181F"))
        et.setHintTextColor(Color.parseColor("#5B6472"))
        et.background = rr(Color.WHITE, 24)
        et.setPadding(dp(16), 0, dp(16), 0)
        et.setSingleLine()
        et.compoundDrawablePadding = dp(8)
        et.setCompoundDrawables(tinted(R.drawable.ic_search, BLUE, 20), null, null, null)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                et.setCompoundDrawables(
                    tinted(R.drawable.ic_search, BLUE, 20), null,
                    if (query.isEmpty()) null else tinted(R.drawable.ic_close, MUTED, 20), null
                )
                refresh()
            }
        })
        et.setOnTouchListener { _, ev ->
            val d = et.compoundDrawables[2]
            if (ev.action == MotionEvent.ACTION_UP && d != null &&
                ev.x >= et.width - et.paddingRight - d.bounds.width() - dp(12)
            ) {
                et.setText("")
                true
            } else {
                false
            }
        }
        h.addView(et, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(10) })

        chipsRow = LinearLayout(this)
        chipsRow.background = rr(Color.argb(46, 255, 255, 255), 24)
        chipsRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        val names = intArrayOf(R.string.chip_all, R.string.chip_recent)
        for (i in names.indices) {
            val tv = TextView(this)
            tv.text = getString(names[i])
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(null, Typeface.BOLD)
            tv.setOnClickListener {
                chip = i
                refresh()
            }
            chipTvs.add(tv)
            chipsRow.addView(tv, LinearLayout.LayoutParams(0, dp(32), 1f))
        }
        h.addView(chipsRow, LinearLayout.LayoutParams(MATCH, WRAP))
        return h
    }

    private fun buildMini(): View {
        mini = FrameLayout(this)
        mini.background = rr(SURF, 16)
        val rad = dp(16).toFloat()
        mini.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, rad)
            }
        }
        mini.clipToOutline = true
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        miniArt = ArtView(this, 40, 12)
        row.addView(miniArt, LinearLayout.LayoutParams(dp(40), dp(40)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        miniT1 = TextView(this)
        miniT1.textSize = 15f
        miniT1.setTypeface(null, Typeface.BOLD)
        miniT1.setTextColor(INK)
        miniT1.maxLines = 1
        miniT1.ellipsize = TextUtils.TruncateAt.END
        miniT2 = TextView(this)
        miniT2.textSize = 13f
        miniT2.setTextColor(MUTED)
        miniT2.maxLines = 1
        miniT2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(miniT1)
        tx.addView(miniT2)
        row.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(10); marginEnd = dp(8) })
        val pb = FrameLayout(this)
        pb.background = ov(BLUE)
        pb.contentDescription = getString(R.string.play)
        miniPlayIc = icon(R.drawable.ic_play, Color.WHITE)
        pb.addView(miniPlayIc, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        pb.setOnClickListener { Player.toggle() }
        row.addView(pb, LinearLayout.LayoutParams(dp(40), dp(40)))
        val nx = FrameLayout(this)
        nx.contentDescription = getString(R.string.next)
        nx.addView(icon(R.drawable.ic_next, INK), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        nx.setOnClickListener { Player.next() }
        row.addView(nx, LinearLayout.LayoutParams(dp(40), dp(40)))
        miniBar = View(this)
        miniBar.setBackgroundColor(BLUE)
        mini.addView(row, FrameLayout.LayoutParams(MATCH, WRAP))
        mini.addView(miniBar, FrameLayout.LayoutParams(0, dp(3), Gravity.BOTTOM or Gravity.START))
        mini.setOnClickListener { startActivity(Intent(this, NowPlayingActivity::class.java)) }
        mini.visibility = View.GONE
        mini.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) }
        return mini
    }

    private fun buildNav(): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setBackgroundColor(BG)
        val line = View(this)
        line.setBackgroundColor(LINE)
        wrap.addView(line, LinearLayout.LayoutParams(MATCH, dp(1)))
        val row = LinearLayout(this)
        val icons = intArrayOf(R.drawable.ic_home, R.drawable.ic_music, R.drawable.ic_album, R.drawable.ic_person)
        val labels = intArrayOf(R.string.tab_home, R.string.tab_songs, R.string.tab_albums, R.string.tab_artists)
        for (k in 0..3) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            val pill = FrameLayout(this)
            val iv = icon(icons[k], MUTED)
            pill.addView(iv, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            cell.addView(pill, LinearLayout.LayoutParams(dp(56), dp(28)))
            val tv = TextView(this)
            tv.text = getString(labels[k])
            tv.textSize = 12f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(MUTED)
            tv.setPadding(0, dp(4), 0, 0)
            cell.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
            cell.setOnClickListener {
                tab = k
                drillKind = 0
                refresh()
            }
            tabPills.add(pill)
            tabIcons.add(iv)
            tabLbls.add(tv)
            row.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        wrap.addView(row, LinearLayout.LayoutParams(MATCH, dp(72)))
        return wrap
    }

    private fun makeRow(): RowHolder {
        val root = LinearLayout(this)
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(8))
        val art = ArtView(this, 48, 14, true)
        root.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.textSize = 16f
        t1.setTypeface(null, Typeface.BOLD)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val t2 = TextView(this)
        t2.textSize = 13f
        t2.setTextColor(MUTED)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(t1)
        tx.addView(t2)
        root.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(12) })
        val btn = FrameLayout(this)
        btn.background = ov(BLUE)
        val bi = icon(R.drawable.ic_play, Color.WHITE)
        btn.addView(bi, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        root.addView(btn, LinearLayout.LayoutParams(dp(44), dp(44)))
        val chev = icon(R.drawable.ic_chevron, MUTED)
        root.addView(chev, LinearLayout.LayoutParams(dp(24), dp(24)))
        val h = RowHolder(root, art, t1, t2, btn, bi, chev)
        root.tag = h
        return h
    }

    private fun bindRow(h: RowHolder, item: Item) {
        h.art.bind(item.track)
        val cur = Player.current
        val isCur = !item.group && cur != null && item.track?.id == cur.id
        h.t1.text = item.title
        h.t1.setTextColor(if (isCur) LINK else INK)
        h.t2.text = item.sub
        h.btn.visibility = if (item.group) View.GONE else View.VISIBLE
        h.chev.visibility = if (item.group) View.VISIBLE else View.GONE
        if (!item.group) {
            h.btnIcon.setImageResource(if (isCur && Player.playing) R.drawable.ic_pause else R.drawable.ic_play)
        }
    }

    // ---------- logika ----------
    private fun songItem(t: Track) = Item(t.title, t.artist + " · " + fmt(t.durationMs), t, false, t.id.toString())

    private fun compute() {
        val q = query.trim().lowercase()
        val fav = Prefs.favs(this)
        fun match(t: Track): Boolean =
            q.isEmpty() || t.title.lowercase().contains(q) || t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)

        if (drillKind != 0) {
            val l = all.filter { t ->
                val k = if (drillKind == 1) t.albumId.toString() else t.groupArtist
                k == drillKey && match(t)
            }
            songsShown = l
            items = l.map { songItem(it) }
            return
        }
        when (tab) {
            0 -> {
                val l = if (q.isEmpty()) emptyList() else all.filter { match(it) }
                songsShown = l
                items = l.map { songItem(it) }
            }
            1 -> {
                var l = all.filter { match(it) }
                if (favOnly) l = l.filter { fav.contains(it.id) }
                if (chip == 1) l = l.sortedByDescending { it.added }.take(50)
                songsShown = l
                items = l.map { songItem(it) }
            }
            2 -> {
                songsShown = emptyList()
                items = all.filter { match(it) }.groupBy { it.albumId }.map { e ->
                    val ts = e.value
                    Item(ts[0].album, ts[0].artist + " · " + getString(R.string.songs_count, ts.size), ts[0], true, e.key.toString())
                }.sortedBy { it.title.lowercase() }
            }
            else -> {
                songsShown = emptyList()
                items = all.filter { match(it) }.groupBy { it.groupArtist }.map { e ->
                    val ts = e.value
                    Item(e.key, getString(R.string.songs_count, ts.size), ts[0], true, e.key)
                }.sortedBy { it.title.lowercase() }
            }
        }
    }

    private fun refresh() {
        compute()
        val home = isHome()
        titleTv.text = if (drillKind != 0) drillTitle else if (tab == 0) homeName() else getString(
            when (tab) {
                1 -> R.string.tab_songs
                2 -> R.string.tab_albums
                else -> R.string.tab_artists
            }
        )
        greetTv.text = greeting()
        greetTv.visibility = if (home) View.VISIBLE else View.GONE
        searchEt.visibility = View.VISIBLE
        shuffleBtn.visibility = if (home) View.GONE else View.VISIBLE
        val showHome = home && query.isBlank() && all.isNotEmpty()
        homeScroll.visibility = if (showHome) View.VISIBLE else View.GONE
        avatar.visibility = if (home) View.VISIBLE else View.GONE
        val photo = Avatar.bitmap(this)
        if (photo != null) {
            avatarImg.setImageBitmap(photo)
            avatarImg.visibility = View.VISIBLE
            avatarTv.visibility = View.GONE
            avatar.background = null
        } else {
            avatarImg.visibility = View.GONE
            avatarTv.visibility = View.VISIBLE
            avatar.background = ov(Avatar.bg(this))
            avatarTv.setTextColor(Avatar.fg(this))
            avatarTv.text = String(Character.toChars(homeName().codePointAt(0))).uppercase()
        }
        titleTv.textSize = if (home) 22f else 28f
        headerBox.setPadding(dp(16), if (home) dp(20) else dp(8), dp(16), if (home) dp(22) else dp(16))
        val tlp = topRow.layoutParams as LinearLayout.LayoutParams
        tlp.bottomMargin = if (home) dp(18) else dp(10)
        topRow.layoutParams = tlp
        backBtn.visibility = if (drillKind != 0) View.VISIBLE else View.GONE
        chipsRow.visibility = if (tab == 1 && drillKind == 0) View.VISIBLE else View.GONE
        starBtn.visibility = if (tab == 1 && drillKind == 0) View.VISIBLE else View.GONE
        gearBtn.visibility = if (drillKind == 0) View.VISIBLE else View.GONE
        starBtn.background = ov(if (favOnly) Color.WHITE else Color.argb(46, 255, 255, 255))
        starIc.setImageResource(if (favOnly) R.drawable.ic_star_filled else R.drawable.ic_star)
        starIc.setColorFilter(if (favOnly) BLUE else Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
        for (i in chipTvs.indices) {
            val on = i == chip
            chipTvs[i].background = if (on) rr(Color.WHITE, 20) else null
            chipTvs[i].setTextColor(if (on) BLUE else Color.WHITE)
        }
        for (k in tabPills.indices) {
            val on = k == tab
            tabPills[k].background = if (on) rr(BLUE, 14) else null
            tabIcons[k].setColorFilter(if (on) Color.WHITE else MUTED, android.graphics.PorterDuff.Mode.SRC_IN)
            tabLbls[k].setTextColor(if (on) LINK else MUTED)
            tabLbls[k].setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
        val perm = hasPerm()
        if (!perm) {
            emptyTitle.text = getString(R.string.empty_title)
            emptyBody.text = getString(R.string.empty_body_perm)
            grantBtn.visibility = View.VISIBLE
        } else if (all.isEmpty()) {
            emptyTitle.text = getString(R.string.empty_title)
            emptyBody.text = getString(R.string.empty_body_none)
            grantBtn.visibility = View.GONE
        } else {
            emptyTitle.text = getString(R.string.no_results)
            emptyBody.text = ""
            grantBtn.visibility = View.GONE
        }
        adapter.notifyDataSetChanged()
        updateMini()
        if (showHome) refreshHome()
    }

    private fun onRow(item: Item) {
        if (item.group) {
            drillKind = if (tab == 2) 1 else 2
            drillKey = item.key
            drillTitle = item.title
            refresh()
            list.setSelection(0)
            return
        }
        val t = item.track ?: return
        if (Player.current?.id == t.id) {
            Player.toggle()
            return
        }
        val i = songsShown.indexOfFirst { it.id == t.id }
        Player.setQueue(songsShown, if (i < 0) 0 else i)
    }

    private fun shuffleAll() {
        val src = if (tab == 1 || drillKind != 0) songsShown else all
        if (src.isEmpty()) return
        Player.shuffleAll(src)
    }

    private fun updateMini() {
        val t = Player.current
        if (t == null || (isHome() && query.isBlank())) {
            mini.visibility = View.GONE
            return
        }
        mini.visibility = View.VISIBLE
        if (miniArt.boundId != t.id) miniArt.bind(t)
        miniT1.text = t.title
        miniT2.text = t.artist
        miniPlayIc.setImageResource(if (Player.playing) R.drawable.ic_pause else R.drawable.ic_play)
        updateBar()
    }

    private fun updateBar() {
        if (Player.current == null) return
        val d = Player.duration()
        val frac = if (d > 0) Player.position().toFloat() / d.toFloat() else 0f
        val lp = miniBar.layoutParams
        lp.width = (mini.width * frac.coerceIn(0f, 1f)).toInt()
        miniBar.layoutParams = lp
    }

    // ---------- beranda ----------
    private fun isHome(): Boolean = tab == 0 && drillKind == 0

    private fun homeName(): String {
        val n = Prefs.name(this)
        return if (n.isEmpty()) getString(R.string.app_name) else n
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return getString(
            when {
                h in 4..10 -> R.string.greet_morning
                h in 11..14 -> R.string.greet_noon
                h in 15..17 -> R.string.greet_afternoon
                else -> R.string.greet_night
            }
        )
    }

    private fun sectionLabel(res: Int): TextView {
        val tv = TextView(this)
        tv.text = getString(res)
        tv.textSize = 13f
        tv.setTextColor(LINK)
        tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(dp(20), dp(18), dp(20), dp(8))
        return tv
    }

    private fun cardLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), 0, dp(16), 0) }

    private fun refreshHome() {
        homeBox.removeAllViews()
        val cur = Player.current
        if (cur != null) {
            homeBox.addView(sectionLabel(R.string.home_continue))
            homeBox.addView(continueCard(cur), cardLp())
        }
        homeBox.addView(sectionLabel(R.string.home_shortcuts))
        homeBox.addView(heroCard(), cardLp().apply { bottomMargin = dp(8) })
        homeBox.addView(twoCards(), cardLp())
        val recent = all.sortedByDescending { it.added }.take(12)
        if (recent.isNotEmpty()) {
            homeBox.addView(sectionLabel(R.string.home_recent_added))
            homeBox.addView(recentRow(recent), LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun continueCard(t: Track): View {
        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = rr(SURF, 16)
        card.setPadding(dp(12), dp(12), dp(12), dp(12))
        val art = ArtView(this, 48, 12)
        art.bind(t)
        card.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = t.title
        t1.textSize = 15f
        t1.setTypeface(null, Typeface.BOLD)
        t1.setTextColor(INK)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val left = (Player.duration() - Player.position()).coerceAtLeast(0L)
        val t2 = TextView(this)
        t2.text = t.artist + " · " + getString(R.string.home_left, fmt(left))
        t2.textSize = 13f
        t2.setTextColor(MUTED)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(t1)
        tx.addView(t2)
        card.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        val pb = FrameLayout(this)
        pb.background = ov(BLUE)
        pb.contentDescription = getString(R.string.play)
        pb.addView(
            icon(if (Player.playing) R.drawable.ic_pause else R.drawable.ic_play, Color.WHITE),
            FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        )
        pb.setOnClickListener { Player.toggle() }
        card.addView(pb, LinearLayout.LayoutParams(dp(40), dp(40)))
        card.setOnClickListener { startActivity(Intent(this, NowPlayingActivity::class.java)) }
        return card
    }

    private fun heroCard(): View {
        val c = LinearLayout(this)
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = rr(BLUE, 18)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        val ic = FrameLayout(this)
        ic.background = ov(Color.argb(46, 255, 255, 255))
        ic.addView(icon(R.drawable.ic_shuffle, Color.WHITE), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        c.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = getString(R.string.shuffle_all)
        t1.textSize = 17f
        t1.setTypeface(null, Typeface.BOLD)
        t1.setTextColor(Color.WHITE)
        val t2 = TextView(this)
        t2.text = getString(R.string.home_shuffle_sub)
        t2.textSize = 13f
        t2.setTextColor(Color.argb(217, 255, 255, 255))
        tx.addView(t1)
        tx.addView(t2)
        c.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(8) })
        c.addView(icon(R.drawable.ic_chevron, Color.WHITE), LinearLayout.LayoutParams(dp(24), dp(24)))
        c.setOnClickListener { if (all.isNotEmpty()) Player.shuffleAll(all) }
        return c
    }

    private fun smallCard(ic: Int, title: Int, count: String, onClick: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rr(SURF, 16)
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.addView(icon(ic, BLUE), LinearLayout.LayoutParams(dp(24), dp(24)))
        val t1 = TextView(this)
        t1.text = getString(title)
        t1.textSize = 16f
        t1.setTypeface(null, Typeface.BOLD)
        t1.setTextColor(INK)
        t1.setPadding(0, dp(12), 0, 0)
        val t2 = TextView(this)
        t2.text = count
        t2.textSize = 13f
        t2.setTextColor(MUTED)
        c.addView(t1)
        c.addView(t2)
        c.setOnClickListener { onClick() }
        return c
    }

    private fun twoCards(): View {
        val row = LinearLayout(this)
        val fav = Prefs.favs(this)
        val favCount = all.count { fav.contains(it.id) }
        val recentCount = all.size.coerceAtMost(50)
        row.addView(
            smallCard(R.drawable.ic_star, R.string.chip_fav, getString(R.string.songs_count, favCount)) {
                tab = 1
                favOnly = true
                chip = 0
                refresh()
            },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) }
        )
        row.addView(
            smallCard(R.drawable.ic_clock, R.string.chip_recent, getString(R.string.songs_count, recentCount)) {
                tab = 1
                favOnly = false
                chip = 1
                refresh()
            },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4) }
        )
        return row
    }

    private fun recentRow(recent: List<Track>): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.setPadding(dp(16), 0, dp(6), 0)
        for (i in recent.indices) {
            val t = recent[i]
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            val art = ArtView(this, 84, 16, true)
            art.bind(t)
            cell.addView(art, LinearLayout.LayoutParams(dp(84), dp(84)))
            val tv = TextView(this)
            tv.text = t.title
            tv.textSize = 12f
            tv.setTextColor(INK)
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(0, dp(4), 0, 0)
            cell.addView(tv, LinearLayout.LayoutParams(dp(84), WRAP))
            cell.setOnClickListener { Player.setQueue(recent, i) }
            row.addView(cell, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(10) })
        }
        hs.addView(row)
        return hs
    }
}
