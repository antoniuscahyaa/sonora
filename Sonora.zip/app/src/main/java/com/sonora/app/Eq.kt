package com.sonora.app

import android.annotation.TargetApi
import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.os.Build
import kotlin.math.ln

class EqPreset(val name: String, val gains: FloatArray)

/**
 * Equalizer 10 pita (31 Hz - 16 kHz, +/-15 dB) + preamp + bass boost.
 * Android 9+ memakai DynamicsProcessing (10 pita sebenarnya + limiter).
 * Android 5-8 memakai Equalizer bawaan perangkat; kurva 10 pita dipetakan ke pita yang tersedia.
 */
object Eq {
    val LABELS = arrayOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    private val CENTERS = doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)
    private val EDGES = floatArrayOf(44f, 88f, 177f, 354f, 707f, 1414f, 2828f, 5657f, 11314f, 20000f)
    const val RANGE = 15f

    val PRESETS: List<EqPreset> = listOf(
        EqPreset("Flat", floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Acoustic", floatArrayOf(4.5f, 4.5f, 3.5f, 1f, 1.5f, 1.5f, 3f, 3.5f, 3f, 2f)),
        EqPreset("Bass Booster", floatArrayOf(6f, 5.5f, 4.5f, 2.5f, 1f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Bass Reducer", floatArrayOf(-6f, -5f, -4f, -2f, -0.5f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Classical", floatArrayOf(4f, 3.5f, 3f, 2.5f, -1.5f, -1.5f, 0f, 2f, 3f, 3.5f)),
        EqPreset("Dance", floatArrayOf(5f, 7f, 5f, 0f, 2f, 3.5f, 5f, 4.5f, 3.5f, 0f)),
        EqPreset("Deep", floatArrayOf(5f, 4.5f, 3f, 1.5f, 3f, 2.5f, 1.5f, -2f, -4f, -5.5f)),
        EqPreset("Electronic", floatArrayOf(4f, 3.5f, 1f, 0f, -2f, 2f, 1f, 1f, 3.5f, 4.5f)),
        EqPreset("Hip-Hop", floatArrayOf(5f, 4f, 1.5f, 3f, -1f, -1f, 1.5f, -0.5f, 1.5f, 3f)),
        EqPreset("Jazz", floatArrayOf(4f, 3f, 1.5f, 2f, -1.5f, -1.5f, 0f, 1.5f, 3f, 3.5f)),
        EqPreset("Latin", floatArrayOf(4.5f, 3f, 0f, 0f, -1.5f, -1.5f, -1.5f, 0f, 3f, 4.5f)),
        EqPreset("Loudness", floatArrayOf(6f, 4f, 0f, 0f, -2f, 0f, -1f, -5f, 5f, 1f)),
        EqPreset("Lounge", floatArrayOf(-3f, -1.5f, -0.5f, 1f, 4f, 2.5f, 0f, -1.5f, 2f, 1f)),
        EqPreset("Piano", floatArrayOf(3f, 2f, 0f, 3.5f, 3f, 1.5f, 3.5f, 4.5f, 3f, 3.5f)),
        EqPreset("Pop", floatArrayOf(-1.5f, -1f, 0f, 2f, 4f, 4f, 2f, 0f, -1f, -1.5f)),
        EqPreset("R&B", floatArrayOf(2.5f, 7f, 6f, 1.5f, -2.5f, -1.5f, 2f, 2.5f, 3f, 3.5f)),
        EqPreset("Rock", floatArrayOf(5f, 4f, 3f, 1.5f, -0.5f, -1f, 0.5f, 2.5f, 3.5f, 4.5f)),
        EqPreset("Small Speakers", floatArrayOf(5.5f, 4.5f, 3.5f, 2.5f, 1.5f, 0f, -1.5f, -2.5f, -3.5f, -4.5f)),
        EqPreset("Spoken Word", floatArrayOf(-4f, -0.5f, 0f, 0.5f, 4f, 5f, 5f, 4.5f, 3f, 0f)),
        EqPreset("Treble Booster", floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 2.5f, 4f, 5.5f, 6f)),
        EqPreset("Treble Reducer", floatArrayOf(0f, 0f, 0f, 0f, 0f, -1f, -2.5f, -4f, -5.5f, -6f)),
        EqPreset("Vocal Booster", floatArrayOf(-2f, -3f, -3f, 1.5f, 4f, 4f, 3.5f, 2f, 0f, -2f))
    )

    private var app: Context? = null
    private var session = 0
    private var dp: Any? = null
    private var legacy: Equalizer? = null
    private var bass: BassBoost? = null

    var available = false
        private set
    var legacyBands = 0
        private set
    val bassAvailable: Boolean
        get() = bass != null

    var on = false
        private set
    var gains = FloatArray(10)
        private set
    var preamp = 0f
        private set
    var bassPct = 0
        private set
    /** Indeks preset aktif; -1 berarti kustom. */
    var preset = 0
        private set

    fun init(ctx: Context, sessionId: Int) {
        app = ctx.applicationContext
        session = sessionId
        load()
        try {
            if (Build.VERSION.SDK_INT >= 28) initDp() else initLegacy()
            available = true
        } catch (e: Throwable) {
            available = false
        }
        try {
            val b = BassBoost(0, sessionId)
            if (b.strengthSupported) {
                bass = b
            } else {
                b.release()
            }
        } catch (e: Throwable) {
            bass = null
        }
        apply()
    }

    private fun load() {
        val c = app ?: return
        on = Prefs.eqOn(c)
        preset = Prefs.eqPreset(c)
        preamp = Prefs.eqPreamp(c)
        bassPct = Prefs.eqBass(c)
        val g = FloatArray(10)
        val parts = Prefs.eqGains(c).split(",")
        if (parts.size == 10) {
            for (i in 0 until 10) g[i] = (parts[i].toFloatOrNull() ?: 0f).coerceIn(-RANGE, RANGE)
        } else if (preset in PRESETS.indices) {
            for (i in 0 until 10) g[i] = PRESETS[preset].gains[i]
        }
        gains = g
    }

    private fun save() {
        val c = app ?: return
        Prefs.setEqOn(c, on)
        Prefs.setEqPreset(c, preset)
        Prefs.setEqPreamp(c, preamp)
        Prefs.setEqBass(c, bassPct)
        Prefs.setEqGains(c, gains.joinToString(",") { it.toString() })
    }

    // ---------- perubahan dari UI ----------
    fun setOn(v: Boolean) {
        on = v
        save()
        apply()
    }

    fun setPreset(i: Int) {
        if (i !in PRESETS.indices) return
        preset = i
        gains = PRESETS[i].gains.copyOf()
        save()
        apply()
    }

    fun setGain(band: Int, v: Float) {
        if (band !in 0..9) return
        val g = gains.copyOf()
        g[band] = v.coerceIn(-RANGE, RANGE)
        gains = g
        preset = -1
        save()
        apply()
    }

    fun setPreamp(v: Float) {
        preamp = v.coerceIn(-RANGE, RANGE)
        save()
        apply()
    }

    fun setBass(pct: Int) {
        bassPct = pct.coerceIn(0, 100)
        save()
        apply()
    }

    fun reset() {
        preamp = 0f
        bassPct = 0
        setPreset(0)
    }

    fun presetName(ctx: Context): String =
        if (preset in PRESETS.indices) PRESETS[preset].name else ctx.getString(R.string.eq_custom)

    // ---------- penerapan ke mesin audio ----------
    fun apply() {
        if (available) {
            try {
                if (Build.VERSION.SDK_INT >= 28) applyDp() else applyLegacy()
            } catch (e: Throwable) {
            }
        }
        try {
            val b = bass
            if (b != null) {
                b.setStrength((bassPct * 10).toShort())
                b.enabled = on && bassPct > 0
            }
        } catch (e: Throwable) {
        }
    }

    @TargetApi(28)
    private fun initDp() {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
            true, 10, false, 0, false, 0, true
        ).build()
        dp = DynamicsProcessing(0, session, cfg)
    }

    @TargetApi(28)
    private fun applyDp() {
        val d = dp as? DynamicsProcessing ?: return
        val eq = DynamicsProcessing.Eq(true, true, 10)
        for (i in 0 until 10) {
            eq.setBand(i, DynamicsProcessing.EqBand(true, EDGES[i], if (on) gains[i] else 0f))
        }
        d.setPreEqAllChannelsTo(eq)
        d.setInputGainAllChannelsTo(if (on) preamp else 0f)
        d.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, on, 0, 1f, 60f, 10f, -2f, 0f))
        d.enabled = on
    }

    private fun initLegacy() {
        val e = Equalizer(0, session)
        legacy = e
        legacyBands = e.numberOfBands.toInt()
    }

    private fun applyLegacy() {
        val e = legacy ?: return
        e.enabled = on
        if (!on) return
        val range = e.bandLevelRange
        val n = e.numberOfBands.toInt()
        for (b in 0 until n) {
            val hz = e.getCenterFreq(b.toShort()) / 1000.0
            val g = interp(hz) + preamp
            val mb = (g * 100f).toInt().coerceIn(range[0].toInt(), range[1].toInt())
            e.setBandLevel(b.toShort(), mb.toShort())
        }
    }

    private fun interp(hz: Double): Float {
        if (hz <= CENTERS[0]) return gains[0]
        if (hz >= CENTERS[9]) return gains[9]
        for (i in 0 until 9) {
            if (hz >= CENTERS[i] && hz <= CENTERS[i + 1]) {
                val t = ((ln(hz) - ln(CENTERS[i])) / (ln(CENTERS[i + 1]) - ln(CENTERS[i]))).toFloat()
                return gains[i] + (gains[i + 1] - gains[i]) * t
            }
        }
        return 0f
    }
}
