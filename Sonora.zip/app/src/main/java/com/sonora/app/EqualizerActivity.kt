package com.sonora.app

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/** Slider vertikal untuk satu pita equalizer (+/-15 dB, langkah 0,5 dB). */
class VSlider(ctx: Context) : View(ctx) {
    var value = 0f
        set(v) {
            field = v
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val zero = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = context.col(R.color.line)
        fill.color = BLUE
        thumb.color = BLUE
        dot.color = Color.WHITE
        zero.color = context.col(R.color.muted)
        zero.alpha = 90
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(resolveSize(context.dp(30), widthMeasureSpec), context.dp(210))
    }

    private fun padV(): Float = context.dp(14).toFloat()

    private fun yFor(v: Float): Float {
        val top = padV()
        val bottom = height - padV()
        return top + (Eq.RANGE - v) / (2f * Eq.RANGE) * (bottom - top)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val tw = context.dp(4) / 2f
        val top = padV()
        val bottom = height - padV()
        canvas.drawRoundRect(cx - tw, top, cx + tw, bottom, tw, tw, track)
        val y0 = yFor(0f)
        val yv = yFor(value)
        canvas.drawRect(cx - context.dp(7).toFloat(), y0 - 1f, cx + context.dp(7).toFloat(), y0 + 1f, zero)
        canvas.drawRoundRect(cx - tw, minOf(y0, yv), cx + tw, maxOf(y0, yv), tw, tw, fill)
        canvas.drawCircle(cx, yv, context.dp(10).toFloat(), thumb)
        canvas.drawCircle(cx, yv, context.dp(4).toFloat(), dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val top = padV()
                val bottom = height - padV()
                val frac = ((e.y - top) / (bottom - top)).coerceIn(0f, 1f)
                var v = Eq.RANGE - frac * 2f * Eq.RANGE
                v = (v * 2f).roundToInt() / 2f
                if (abs(v) < 0.25f) v = 0f
                if (v != value) {
                    value = v
                    onChange?.invoke(v)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

class EqualizerActivity : BaseActivity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val SURF by lazy { col(R.color.surf) }
    private val LINK by lazy { col(R.color.link) }

    private lateinit var toggle: ToggleView
    private lateinit var content: LinearLayout
    private lateinit var presetTv: TextView
    private lateinit var preampTv: TextView
    private lateinit var preampSb: SeekBar
    private lateinit var bassTv: TextView
    private lateinit var bassSb: SeekBar
    private val valTvs = ArrayList<TextView>()
    private val sliders = ArrayList<VSlider>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
        syncUi()
    }

    private fun build(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val h = LinearLayout(this)
        h.background = HeaderBg(dp(36).toFloat())
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(16), dp(8), dp(16), dp(16))
        h.addView(
            glassBtn(R.drawable.ic_back, getString(R.string.back)) { finish() },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        )
        val title = TextView(this)
        title.text = getString(R.string.eq_title)
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.setTypeface(null, Typeface.BOLD)
        h.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        toggle = ToggleView(this)
        toggle.setCheckedSilently(Eq.on)
        toggle.onChange = {
            Eq.setOn(it)
            syncUi()
        }
        h.addView(toggle, LinearLayout.LayoutParams(dp(48), dp(28)))
        root.addView(h, LinearLayout.LayoutParams(MATCH, WRAP))

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        val sv = ScrollView(this)
        sv.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        if (!Eq.available) {
            val tv = TextView(this)
            tv.text = getString(R.string.eq_unavailable)
            tv.textSize = 15f
            tv.setTextColor(MUTED)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(16), dp(32), dp(16), dp(32))
            content.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            toggle.visibility = View.GONE
            return root
        }

        // ---- preset ----
        val pc = LinearLayout(this)
        pc.gravity = Gravity.CENTER_VERTICAL
        pc.background = rr(SURF, 16)
        pc.setPadding(dp(16), dp(12), dp(8), dp(12))
        val ptx = LinearLayout(this)
        ptx.orientation = LinearLayout.VERTICAL
        val pl = TextView(this)
        pl.text = getString(R.string.eq_preset)
        pl.textSize = 12f
        pl.setTextColor(MUTED)
        presetTv = TextView(this)
        presetTv.textSize = 18f
        presetTv.setTypeface(null, Typeface.BOLD)
        presetTv.setTextColor(INK)
        ptx.addView(pl)
        ptx.addView(presetTv)
        pc.addView(ptx, LinearLayout.LayoutParams(0, WRAP, 1f))
        val reset = TextView(this)
        reset.text = getString(R.string.eq_reset)
        reset.textSize = 14f
        reset.setTypeface(null, Typeface.BOLD)
        reset.setTextColor(LINK)
        reset.setPadding(dp(14), dp(10), dp(14), dp(10))
        reset.setOnClickListener {
            Eq.reset()
            syncUi()
        }
        pc.addView(reset, LinearLayout.LayoutParams(WRAP, WRAP))
        pc.setOnClickListener { pickPreset() }
        content.addView(pc, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- 10 pita ----
        val bands = LinearLayout(this)
        bands.background = rr(SURF, 16)
        bands.setPadding(dp(8), dp(12), dp(8), dp(12))
        for (i in 0 until 10) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val vt = TextView(this)
            vt.textSize = 10f
            vt.setTextColor(MUTED)
            vt.gravity = Gravity.CENTER
            val sl = VSlider(this)
            sl.onChange = { v ->
                Eq.setGain(i, v)
                valTvs[i].text = fmtDb(v)
                presetTv.text = Eq.presetName(this)
            }
            val ft = TextView(this)
            ft.text = Eq.LABELS[i]
            ft.textSize = 11f
            ft.setTextColor(INK)
            ft.gravity = Gravity.CENTER
            col.addView(vt, LinearLayout.LayoutParams(MATCH, WRAP))
            col.addView(sl, LinearLayout.LayoutParams(MATCH, WRAP))
            col.addView(ft, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
            valTvs.add(vt)
            sliders.add(sl)
            bands.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        content.addView(bands, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // ---- preamp ----
        val pre = sliderCard(R.string.eq_preamp, 60)
        preampTv = pre.first
        preampSb = pre.second
        preampSb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p / 2f - Eq.RANGE
                preampTv.text = fmtDb(v)
                if (fromUser) Eq.setPreamp(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // ---- bass ----
        val bs = sliderCard(R.string.eq_bass, 100)
        bassTv = bs.first
        bassSb = bs.second
        bassSb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                bassTv.text = "$p%"
                if (fromUser) Eq.setBass(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        if (!Eq.bassAvailable) (bassSb.parent as View).visibility = View.GONE

        if (Eq.legacyBands > 0) {
            val note = TextView(this)
            note.text = getString(R.string.eq_legacy_note, Eq.legacyBands)
            note.textSize = 12f
            note.setTextColor(MUTED)
            note.setPadding(dp(4), dp(12), dp(4), 0)
            content.addView(note, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return root
    }

    private fun sliderCard(label: Int, max: Int): Pair<TextView, SeekBar> {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rr(SURF, 16)
        card.setPadding(dp(16), dp(12), dp(16), dp(8))
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val l = TextView(this)
        l.text = getString(label)
        l.textSize = 15f
        l.setTypeface(null, Typeface.BOLD)
        l.setTextColor(INK)
        val v = TextView(this)
        v.textSize = 14f
        v.setTextColor(MUTED)
        row.addView(l, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(v, LinearLayout.LayoutParams(WRAP, WRAP))
        val sb = SeekBar(this)
        sb.max = max
        sb.progressTintList = ColorStateList.valueOf(BLUE)
        sb.thumbTintList = ColorStateList.valueOf(BLUE)
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        content.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        return Pair(v, sb)
    }

    private fun fmtDb(v: Float): String {
        val t = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()
        return if (v > 0f) "+$t" else t
    }

    private fun syncUi() {
        toggle.setCheckedSilently(Eq.on)
        if (!Eq.available) return
        presetTv.text = Eq.presetName(this)
        for (i in 0 until 10) {
            sliders[i].value = Eq.gains[i]
            valTvs[i].text = fmtDb(Eq.gains[i])
        }
        preampSb.progress = ((Eq.preamp + Eq.RANGE) * 2f).roundToInt()
        preampTv.text = fmtDb(Eq.preamp)
        bassSb.progress = Eq.bassPct
        bassTv.text = Eq.bassPct.toString() + "%"
        content.alpha = if (Eq.on) 1f else 0.45f
    }

    private fun pickPreset() {
        val names = Array(Eq.PRESETS.size) { i -> Eq.PRESETS[i].name }
        AlertDialog.Builder(this)
            .setTitle(R.string.eq_preset)
            .setSingleChoiceItems(names, Eq.preset) { d, which ->
                Eq.setPreset(which)
                if (!Eq.on) Eq.setOn(true)
                d.dismiss()
                syncUi()
            }
            .show()
    }
}
