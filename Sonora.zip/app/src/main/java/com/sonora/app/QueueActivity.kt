package com.sonora.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

private class QHolder(val root: LinearLayout, val art: ArtView, val t1: TextView, val t2: TextView, val mark: ImageView)

class QueueActivity : BaseActivity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINK by lazy { col(R.color.link) }

    private lateinit var list: ListView
    private lateinit var subTv: TextView
    private val listener: () -> Unit = {
        if (Player.queue.isEmpty()) finish() else update()
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = Player.queue.size
        override fun getItem(position: Int): Any = Player.queue[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h = (convertView?.tag as? QHolder) ?: makeRow()
            val t = Player.queue[position]
            val cur = position == Player.index
            h.art.bind(t)
            h.t1.text = t.title
            h.t1.setTextColor(if (cur) LINK else INK)
            h.t2.text = t.artist + " · " + fmt(t.durationMs)
            h.mark.setImageResource(if (cur) R.drawable.ic_equalizer else R.drawable.ic_queue)
            h.mark.setColorFilter(if (cur) LINK else MUTED, android.graphics.PorterDuff.Mode.SRC_IN)
            return h.root
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars(BG)
        setContentView(build())
    }

    override fun onStart() {
        super.onStart()
        Player.addListener(listener)
        update()
        list.setSelection(maxOf(0, Player.index - 2))
    }

    override fun onStop() {
        super.onStop()
        Player.removeListener(listener)
    }

    private fun update() {
        subTv.text = getString(R.string.songs_count, Player.queue.size)
        adapter.notifyDataSetChanged()
    }

    private fun build(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val h = LinearLayout(this)
        val r = dp(36).toFloat()
        h.background = HeaderBg(r)
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(16), dp(8), dp(16), dp(16))
        h.addView(
            glassBtn(R.drawable.ic_back, getString(R.string.back)) { finish() },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        )
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = getString(R.string.queue)
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.setTypeface(null, Typeface.BOLD)
        subTv = TextView(this)
        subTv.textSize = 14f
        subTv.setTextColor(Color.argb(224, 255, 255, 255))
        tx.addView(title)
        tx.addView(subTv)
        h.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(h, LinearLayout.LayoutParams(MATCH, WRAP))

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.setPadding(0, dp(8), 0, dp(8))
        list.clipToPadding = false
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> Player.playAt(pos) }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return root
    }

    private fun makeRow(): QHolder {
        val root = LinearLayout(this)
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(8))
        val art = ArtView(this, 48, 14, true)
        root.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.textSize = 16f
        t1.setTypeface(null, Typeface.BOLD)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val t2 = TextView(this)
        t2.textSize = 13f
        t2.setTextColor(MUTED)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        tx.addView(t1)
        tx.addView(t2)
        root.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(12) })
        val mark = icon(R.drawable.ic_queue, MUTED)
        root.addView(mark, LinearLayout.LayoutParams(dp(22), dp(22)))
        val hd = QHolder(root, art, t1, t2, mark)
        root.tag = hd
        return hd
    }
}
