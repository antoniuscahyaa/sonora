package com.sonora.app

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast

/** Pemutar tunggal untuk seluruh aplikasi. Semua pemanggilan dari main thread. */
object Player {
    private lateinit var app: Context
    private lateinit var am: AudioManager
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var resumeOnFocus = false
    private var errors = 0
    private var focusReq: AudioFocusRequest? = null
    private var base: List<Track> = emptyList()
    private val listeners = ArrayList<() -> Unit>()

    // volume: fade (vol) dan ducking dari audio focus (duck)
    private var vol = 1f
    private var duck = 1f
    private var fadeGen = 0

    private var sleepPending = false
    private var pendingSeek = 0
    private var restored = false

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    var queue: List<Track> = emptyList()
        private set
    var index: Int = -1
        private set
    var playing: Boolean = false
        private set
    var shuffle: Boolean = false
        private set
    var repeat: Int = 0 // 0 mati, 1 semua, 2 satu lagu
        private set
    var sleepAt: Long = 0L
        private set

    val sleepWaiting: Boolean
        get() = sleepPending

    val current: Track?
        get() = queue.getOrNull(index)

    fun init(ctx: Context) {
        app = ctx.applicationContext
        am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        shuffle = Prefs.shuffle(app)
        repeat = Prefs.repeat(app)
    }

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun changed() {
        for (l in ArrayList(listeners)) l()
    }

    // ---------- volume & fade ----------
    private fun applyVol() {
        val v = vol * duck
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
    }

    private fun fade(to: Float, ms: Int, done: (() -> Unit)?) {
        val gen = ++fadeGen
        if (ms <= 0 || !Prefs.fade(app)) {
            vol = to
            applyVol()
            done?.invoke()
            return
        }
        val from = vol
        val steps = (ms / 40).coerceAtLeast(1)
        var n = 0
        val r = object : Runnable {
            override fun run() {
                if (gen != fadeGen) return
                n++
                vol = from + (to - from) * n / steps
                applyVol()
                if (n >= steps) done?.invoke() else main.postDelayed(this, 40)
            }
        }
        main.post(r)
    }

    // ---------- simpan & lanjutkan ----------
    private val saveTick = object : Runnable {
        override fun run() {
            if (playing) {
                saveNow()
                main.postDelayed(this, 5000)
            }
        }
    }

    private fun startSave() {
        main.removeCallbacks(saveTick)
        main.postDelayed(saveTick, 5000)
    }

    private fun saveNow() {
        if (current == null) return
        Prefs.savePos(app, index, if (prepared) position() else pendingSeek)
    }

    private fun saveQueue() {
        Prefs.saveQueue(app, queue.map { it.id }, index)
    }

    /** Memulihkan antrean terakhir (dalam keadaan jeda) setelah library berhasil dimuat. */
    fun restore(all: List<Track>) {
        if (all.isEmpty() || restored) return
        restored = true
        if (!Prefs.resumeLast(app) || queue.isNotEmpty()) return
        val ids = Prefs.savedQueue(app)
        if (ids.isEmpty()) return
        val byId = HashMap<Long, Track>()
        for (t in all) byId[t.id] = t
        val q = ArrayList<Track>()
        for (id in ids) {
            val t = byId[id]
            if (t != null) q.add(t)
        }
        if (q.isEmpty()) return
        val curId = ids.getOrNull(Prefs.savedIndex(app))
        var idx = q.indexOfFirst { it.id == curId }
        val found = idx >= 0
        if (!found) idx = 0
        base = q
        queue = q
        index = idx
        pendingSeek = if (found) Prefs.savedPos(app) else 0
        errors = 0
        load(false)
    }

    // ---------- antrean ----------
    fun setQueue(list: List<Track>, start: Int) {
        if (list.isEmpty()) return
        val s = start.coerceIn(0, list.size - 1)
        base = list
        if (shuffle) {
            val first = list[s]
            queue = listOf(first) + list.filter { it.id != first.id }.shuffled()
            index = 0
        } else {
            queue = list
            index = s
        }
        errors = 0
        pendingSeek = 0
        saveQueue()
        load(true)
    }

    fun shuffleAll(list: List<Track>) {
        if (list.isEmpty()) return
        shuffle = true
        Prefs.setShuffle(app, true)
        setQueue(list, list.indices.random())
    }

    fun playAt(i: Int) {
        if (i !in queue.indices) return
        index = i
        errors = 0
        pendingSeek = 0
        load(true)
    }

    fun toggleShuffle() {
        shuffle = !shuffle
        Prefs.setShuffle(app, shuffle)
        val cur = current
        if (cur != null) {
            if (shuffle) {
                queue = listOf(cur) + base.filter { it.id != cur.id }.shuffled()
                index = 0
            } else {
                queue = base
                index = base.indexOfFirst { it.id == cur.id }.coerceAtLeast(0)
            }
            saveQueue()
        }
        changed()
    }

    fun cycleRepeat() {
        repeat = (repeat + 1) % 3
        Prefs.setRepeat(app, repeat)
        changed()
    }

    // ---------- kontrol ----------
    fun toggle() {
        if (playing) pause() else play()
    }

    fun play() {
        if (current == null) return
        if (mp == null) {
            load(true)
            return
        }
        fadeGen++
        wantPlay = true
        if (!requestFocus()) return
        playing = true
        if (prepared) {
            var wasPlaying = false
            try {
                wasPlaying = mp?.isPlaying == true
            } catch (e: Exception) {
            }
            if (!wasPlaying && Prefs.fade(app)) {
                vol = 0f
                applyVol()
            }
            mp?.start()
            fade(1f, 350, null)
        }
        startSave()
        ensureService()
        changed()
    }

    fun pause(immediate: Boolean = false) {
        pauseInternal(true, immediate)
    }

    private fun pauseInternal(abandon: Boolean, immediate: Boolean) {
        wantPlay = false
        val wasPlaying = playing
        playing = false
        if (abandon) abandonFocus()
        if (prepared && wasPlaying && !immediate && Prefs.fade(app)) {
            val p = mp
            fade(0f, 300) {
                if (mp === p && !wantPlay) {
                    try {
                        if (p?.isPlaying == true) p?.pause()
                    } catch (e: Exception) {
                    }
                }
            }
        } else {
            fadeGen++
            if (prepared) {
                try {
                    if (mp?.isPlaying == true) mp?.pause()
                } catch (e: Exception) {
                }
            }
            vol = 1f
            applyVol()
        }
        saveNow()
        changed()
    }

    fun next() {
        advance(1, false)
    }

    fun prev() {
        if (position() > 3000) seekTo(0) else advance(-1, false)
    }

    fun seekTo(ms: Int) {
        if (prepared) mp?.seekTo(ms)
        changed()
    }

    fun position(): Int = if (prepared) (mp?.currentPosition ?: 0) else 0

    fun duration(): Long {
        val d = if (prepared) (mp?.duration ?: 0) else 0
        return if (d > 0) d.toLong() else (current?.durationMs ?: 0L)
    }

    private val sleepRunnable = Runnable {
        sleepAt = 0L
        if (Prefs.sleepFinish(app) && playing) {
            sleepPending = true
            changed()
        } else {
            pause()
        }
    }

    fun setSleep(minutes: Int) {
        main.removeCallbacks(sleepRunnable)
        sleepPending = false
        if (minutes > 0) {
            sleepAt = System.currentTimeMillis() + minutes * 60_000L
            main.postDelayed(sleepRunnable, minutes * 60_000L)
        } else {
            sleepAt = 0L
        }
        changed()
    }

    /** Hentikan pemutaran setelah lagu yang sedang diputar selesai. */
    fun sleepAfterSong() {
        main.removeCallbacks(sleepRunnable)
        sleepAt = 0L
        sleepPending = true
        changed()
    }

    // ---------- internal ----------
    private fun advance(d: Int, auto: Boolean) {
        if (queue.isEmpty()) return
        var i = index + d
        if (i >= queue.size) {
            if (auto && repeat == 0) {
                index = 0
                load(false)
                return
            }
            i = 0
        } else if (i < 0) {
            i = queue.size - 1
        }
        index = i
        pendingSeek = 0
        load(true)
    }

    private fun load(autoplay: Boolean) {
        releaseMp()
        fadeGen++
        vol = 1f
        val t = current
        if (t == null) {
            playing = false
            changed()
            return
        }
        if (pendingSeek == 0) Prefs.savePos(app, index, 0)
        wantPlay = autoplay
        playing = autoplay
        val p = MediaPlayer()
        mp = p
        prepared = false
        try {
            p.setAudioAttributes(attrs)
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(app, t.uri)
            p.setOnPreparedListener { onPrepared(p) }
            p.setOnCompletionListener { onCompleted() }
            p.setOnErrorListener { _, _, _ ->
                onError()
                true
            }
            p.prepareAsync()
            if (autoplay) {
                if (requestFocus()) {
                    ensureService()
                } else {
                    wantPlay = false
                    playing = false
                }
            }
        } catch (e: Exception) {
            onError()
            return
        }
        changed()
    }

    private fun onPrepared(p: MediaPlayer) {
        if (p !== mp) return
        prepared = true
        vol = 1f
        applyVol()
        if (pendingSeek > 0) {
            try {
                p.seekTo(pendingSeek)
            } catch (e: Exception) {
            }
            pendingSeek = 0
        }
        if (wantPlay) {
            if (Prefs.fade(app)) {
                vol = 0f
                applyVol()
            }
            p.start()
            playing = true
            errors = 0
            fade(1f, 350, null)
            startSave()
        }
        changed()
    }

    private fun onCompleted() {
        if (sleepPending) {
            sleepPending = false
            if (queue.size > 1) index = (index + 1) % queue.size
            abandonFocus()
            pendingSeek = 0
            load(false)
            return
        }
        if (repeat == 2) {
            mp?.seekTo(0)
            mp?.start()
            return
        }
        advance(1, true)
    }

    private fun onError() {
        errors++
        pendingSeek = 0
        Toast.makeText(app, R.string.song_error, Toast.LENGTH_SHORT).show()
        if (errors < queue.size.coerceAtLeast(1)) {
            advance(1, true)
        } else {
            errors = 0
            releaseMp()
            playing = false
            wantPlay = false
            changed()
        }
    }

    private fun releaseMp() {
        val p = mp
        if (p != null) {
            p.setOnPreparedListener(null)
            p.setOnCompletionListener(null)
            p.setOnErrorListener(null)
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
        mp = null
        prepared = false
    }

    private fun ensureService() {
        if (PlaybackService.running) return
        val i = Intent(app, PlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
    }

    // ---------- audio focus ----------
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                pauseInternal(true, true)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnFocus = playing
                pauseInternal(false, true)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                duck = 0.25f
                applyVol()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                duck = 1f
                applyVol()
                if (resumeOnFocus) {
                    resumeOnFocus = false
                    play()
                }
            }
            else -> {}
        }
    }

    @Suppress("DEPRECATION")
    private fun requestFocus(): Boolean {
        val r = if (Build.VERSION.SDK_INT >= 26) {
            var req = focusReq
            if (req == null) {
                req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(focusListener, main)
                    .build()
                focusReq = req
            }
            am.requestAudioFocus(req!!)
        } else {
            am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            val req = focusReq
            if (req != null) am.abandonAudioFocusRequest(req)
        } else {
            am.abandonAudioFocus(focusListener)
        }
    }
}
