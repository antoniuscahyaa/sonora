package com.sonora.app

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast

/** Pemutar tunggal untuk seluruh aplikasi. Semua pemanggilan dari main thread. */
object Player {
    private lateinit var app: Context
    private lateinit var am: AudioManager
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var resumeOnFocus = false
    private var errors = 0
    private var focusReq: AudioFocusRequest? = null
    private var base: List<Track> = emptyList()
    private val listeners = ArrayList<() -> Unit>()

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    var queue: List<Track> = emptyList()
        private set
    var index: Int = -1
        private set
    var playing: Boolean = false
        private set
    var shuffle: Boolean = false
        private set
    var repeat: Int = 0 // 0 mati, 1 semua, 2 satu lagu
        private set
    var sleepAt: Long = 0L
        private set

    val current: Track?
        get() = queue.getOrNull(index)

    fun init(ctx: Context) {
        app = ctx.applicationContext
        am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        shuffle = Prefs.shuffle(app)
        repeat = Prefs.repeat(app)
    }

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun changed() {
        for (l in ArrayList(listeners)) l()
    }

    // ---------- antrean ----------
    fun setQueue(list: List<Track>, start: Int) {
        if (list.isEmpty()) return
        val s = start.coerceIn(0, list.size - 1)
        base = list
        if (shuffle) {
            val first = list[s]
            queue = listOf(first) + list.filter { it.id != first.id }.shuffled()
            index = 0
        } else {
            queue = list
            index = s
        }
        errors = 0
        load(true)
    }

    fun shuffleAll(list: List<Track>) {
        if (list.isEmpty()) return
        shuffle = true
        Prefs.setShuffle(app, true)
        setQueue(list, list.indices.random())
    }

    fun playAt(i: Int) {
        if (i !in queue.indices) return
        index = i
        errors = 0
        load(true)
    }

    fun toggleShuffle() {
        shuffle = !shuffle
        Prefs.setShuffle(app, shuffle)
        val cur = current
        if (cur != null) {
            if (shuffle) {
                queue = listOf(cur) + base.filter { it.id != cur.id }.shuffled()
                index = 0
            } else {
                queue = base
                index = base.indexOfFirst { it.id == cur.id }.coerceAtLeast(0)
            }
        }
        changed()
    }

    fun cycleRepeat() {
        repeat = (repeat + 1) % 3
        Prefs.setRepeat(app, repeat)
        changed()
    }

    // ---------- kontrol ----------
    fun toggle() {
        if (playing) pause() else play()
    }

    fun play() {
        if (current == null) return
        if (mp == null) {
            load(true)
            return
        }
        wantPlay = true
        if (!requestFocus()) return
        playing = true
        if (prepared) mp?.start()
        ensureService()
        changed()
    }

    fun pause() {
        pauseInternal(true)
    }

    private fun pauseInternal(abandon: Boolean) {
        wantPlay = false
        if (prepared) {
            try {
                if (mp?.isPlaying == true) mp?.pause()
            } catch (e: Exception) {
            }
        }
        playing = false
        if (abandon) abandonFocus()
        changed()
    }

    fun next() {
        advance(1, false)
    }

    fun prev() {
        if (position() > 3000) seekTo(0) else advance(-1, false)
    }

    fun seekTo(ms: Int) {
        if (prepared) mp?.seekTo(ms)
        changed()
    }

    fun position(): Int = if (prepared) (mp?.currentPosition ?: 0) else 0

    fun duration(): Long {
        val d = if (prepared) (mp?.duration ?: 0) else 0
        return if (d > 0) d.toLong() else (current?.durationMs ?: 0L)
    }

    private val sleepRunnable = Runnable {
        sleepAt = 0L
        pause()
    }

    fun setSleep(minutes: Int) {
        main.removeCallbacks(sleepRunnable)
        if (minutes > 0) {
            sleepAt = System.currentTimeMillis() + minutes * 60_000L
            main.postDelayed(sleepRunnable, minutes * 60_000L)
        } else {
            sleepAt = 0L
        }
        changed()
    }

    // ---------- internal ----------
    private fun advance(d: Int, auto: Boolean) {
        if (queue.isEmpty()) return
        var i = index + d
        if (i >= queue.size) {
            if (auto && repeat == 0) {
                index = 0
                load(false)
                return
            }
            i = 0
        } else if (i < 0) {
            i = queue.size - 1
        }
        index = i
        load(true)
    }

    private fun load(autoplay: Boolean) {
        releaseMp()
        val t = current
        if (t == null) {
            playing = false
            changed()
            return
        }
        wantPlay = autoplay
        playing = autoplay
        val p = MediaPlayer()
        mp = p
        prepared = false
        try {
            p.setAudioAttributes(attrs)
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(app, t.uri)
            p.setOnPreparedListener { onPrepared(p) }
            p.setOnCompletionListener { onCompleted() }
            p.setOnErrorListener { _, _, _ ->
                onError()
                true
            }
            p.prepareAsync()
            if (autoplay) {
                if (requestFocus()) {
                    ensureService()
                } else {
                    wantPlay = false
                    playing = false
                }
            }
        } catch (e: Exception) {
            onError()
            return
        }
        changed()
    }

    private fun onPrepared(p: MediaPlayer) {
        if (p !== mp) return
        prepared = true
        if (wantPlay) {
            p.start()
            playing = true
            errors = 0
        }
        changed()
    }

    private fun onCompleted() {
        if (repeat == 2) {
            mp?.seekTo(0)
            mp?.start()
            return
        }
        advance(1, true)
    }

    private fun onError() {
        errors++
        Toast.makeText(app, R.string.song_error, Toast.LENGTH_SHORT).show()
        if (errors < queue.size.coerceAtLeast(1)) {
            advance(1, true)
        } else {
            errors = 0
            releaseMp()
            playing = false
            wantPlay = false
            changed()
        }
    }

    private fun releaseMp() {
        val p = mp
        if (p != null) {
            p.setOnPreparedListener(null)
            p.setOnCompletionListener(null)
            p.setOnErrorListener(null)
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
        mp = null
        prepared = false
    }

    private fun ensureService() {
        if (PlaybackService.running) return
        val i = Intent(app, PlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
    }

    // ---------- audio focus ----------
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                pauseInternal(true)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnFocus = playing
                pauseInternal(false)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> mp?.setVolume(0.25f, 0.25f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (resumeOnFocus) {
                    resumeOnFocus = false
                    play()
                }
            }
            else -> {}
        }
    }

    @Suppress("DEPRECATION")
    private fun requestFocus(): Boolean {
        val r = if (Build.VERSION.SDK_INT >= 26) {
            var req = focusReq
            if (req == null) {
                req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(focusListener, main)
                    .build()
                focusReq = req
            }
            am.requestAudioFocus(req!!)
        } else {
            am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            val req = focusReq
            if (req != null) am.abandonAudioFocusRequest(req)
        } else {
            am.abandonAudioFocus(focusListener)
        }
    }
}
