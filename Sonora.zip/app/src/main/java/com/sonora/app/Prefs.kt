package com.sonora.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("sonora", Context.MODE_PRIVATE)

    // ---------- favorit ----------
    fun favs(c: Context): Set<Long> {
        val s = sp(c).getStringSet("fav", null) ?: return emptySet()
        val out = HashSet<Long>()
        for (x in s) {
            val v = x.toLongOrNull()
            if (v != null) out.add(v)
        }
        return out
    }

    fun isFav(c: Context, id: Long): Boolean = favs(c).contains(id)

    fun toggleFav(c: Context, id: Long): Boolean {
        val s = HashSet<String>(sp(c).getStringSet("fav", null) ?: emptySet<String>())
        val k = id.toString()
        val on = !s.contains(k)
        if (on) s.add(k) else s.remove(k)
        sp(c).edit().putStringSet("fav", s).apply()
        return on
    }

    fun clearFavs(c: Context) { sp(c).edit().remove("fav").apply() }

    // ---------- pemutar ----------
    fun shuffle(c: Context): Boolean = sp(c).getBoolean("shuffle", false)
    fun setShuffle(c: Context, v: Boolean) { sp(c).edit().putBoolean("shuffle", v).apply() }
    fun repeat(c: Context): Int = sp(c).getInt("repeat", 0)
    fun setRepeat(c: Context, v: Int) { sp(c).edit().putInt("repeat", v).apply() }

    // ---------- pengaturan: tampilan ----------
    /** 0 ikuti sistem, 1 terang, 2 gelap */
    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) { sp(c).edit().putInt("theme", v).apply() }
    fun covers(c: Context): Boolean = sp(c).getBoolean("covers", true)
    fun setCovers(c: Context, v: Boolean) { sp(c).edit().putBoolean("covers", v).apply() }

    // ---------- pengaturan: library ----------
    /** Lagu lebih pendek dari ini (detik) disembunyikan. 0 = tampilkan semua. */
    fun minSec(c: Context): Int = sp(c).getInt("minsec", 30)
    fun setMinSec(c: Context, v: Int) { sp(c).edit().putInt("minsec", v).apply() }
    fun excluded(c: Context): Set<String> = HashSet<String>(sp(c).getStringSet("excl", null) ?: emptySet<String>())
    fun setExcluded(c: Context, v: Set<String>) { sp(c).edit().putStringSet("excl", HashSet<String>(v)).apply() }
    /** 0 judul, 1 artis, 2 terbaru ditambahkan */
    fun sort(c: Context): Int = sp(c).getInt("sort", 0)
    fun setSort(c: Context, v: Int) { sp(c).edit().putInt("sort", v).apply() }
    fun mergeArtists(c: Context): Boolean = sp(c).getBoolean("merge", true)
    fun setMergeArtists(c: Context, v: Boolean) { sp(c).edit().putBoolean("merge", v).apply() }

    // ---------- pengaturan: pemutaran ----------
    fun pauseOnUnplug(c: Context): Boolean = sp(c).getBoolean("unplug", true)
    fun setPauseOnUnplug(c: Context, v: Boolean) { sp(c).edit().putBoolean("unplug", v).apply() }
    fun resumeLast(c: Context): Boolean = sp(c).getBoolean("resume", true)
    fun setResumeLast(c: Context, v: Boolean) { sp(c).edit().putBoolean("resume", v).apply() }
    fun fade(c: Context): Boolean = sp(c).getBoolean("fade", true)
    fun setFade(c: Context, v: Boolean) { sp(c).edit().putBoolean("fade", v).apply() }
    fun sleepDefault(c: Context): Int = sp(c).getInt("sleepdef", 30)
    fun setSleepDefault(c: Context, v: Int) { sp(c).edit().putInt("sleepdef", v).apply() }
    fun sleepFinish(c: Context): Boolean = sp(c).getBoolean("sleepfin", false)
    fun setSleepFinish(c: Context, v: Boolean) { sp(c).edit().putBoolean("sleepfin", v).apply() }

    // ---------- status pemutaran terakhir ----------
    fun saveQueue(c: Context, ids: List<Long>, index: Int) {
        sp(c).edit().putString("rq", ids.joinToString(",")).putInt("ri", index).putInt("rp", 0).apply()
    }

    fun savePos(c: Context, index: Int, pos: Int) {
        sp(c).edit().putInt("ri", index).putInt("rp", pos).apply()
    }

    fun savedQueue(c: Context): List<Long> {
        val s = sp(c).getString("rq", null) ?: return emptyList()
        if (s.isEmpty()) return emptyList()
        val out = ArrayList<Long>()
        for (x in s.split(",")) {
            val v = x.toLongOrNull()
            if (v != null) out.add(v)
        }
        return out
    }

    fun savedIndex(c: Context): Int = sp(c).getInt("ri", 0)
    fun savedPos(c: Context): Int = sp(c).getInt("rp", 0)
}
