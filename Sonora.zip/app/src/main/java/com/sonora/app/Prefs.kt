package com.sonora.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("sonora", Context.MODE_PRIVATE)

    fun favs(c: Context): Set<Long> {
        val s = sp(c).getStringSet("fav", null) ?: return emptySet()
        val out = HashSet<Long>()
        for (x in s) {
            val v = x.toLongOrNull()
            if (v != null) out.add(v)
        }
        return out
    }

    fun isFav(c: Context, id: Long): Boolean = favs(c).contains(id)

    fun toggleFav(c: Context, id: Long): Boolean {
        val s = HashSet<String>(sp(c).getStringSet("fav", null) ?: emptySet<String>())
        val k = id.toString()
        val on = !s.contains(k)
        if (on) s.add(k) else s.remove(k)
        sp(c).edit().putStringSet("fav", s).apply()
        return on
    }

    fun shuffle(c: Context): Boolean = sp(c).getBoolean("shuffle", false)
    fun setShuffle(c: Context, v: Boolean) { sp(c).edit().putBoolean("shuffle", v).apply() }
    fun repeat(c: Context): Int = sp(c).getInt("repeat", 0)
    fun setRepeat(c: Context, v: Int) { sp(c).edit().putInt("repeat", v).apply() }
}
