package com.sonora.app

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val added: Long,
    val path: String = "",
    /** Artis utama untuk pengelompokan di tab Artis (mis. "Danilla/Teddy Adhitya" -> "Danilla"). */
    val groupArtist: String = artist
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}
